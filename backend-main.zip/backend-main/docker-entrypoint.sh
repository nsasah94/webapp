#!/bin/sh
set -e
find . -name "server.pid" -exec rm {} \;
exec bundle exec "$@"
