# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: "Star Wars" }, { name: "Lord of the Rings" }])
#   Character.create(name: "Luke", movie: movies.first)
require 'smarter_csv'

puts "Users Seed"
SmarterCSV.process("db/seeds/users.csv").each do |user|
  User.create(user)
end

puts "Countries Seed"
SmarterCSV.process("db/seeds/countries.csv", key_mapping: { namelocale: :nameLocale }).each do |country|
  Country.create(country)
end

puts "Cities Seed"
SmarterCSV.process("db/seeds/cities.csv", key_mapping: { namelocale: :nameLocale }).each do |city|
  @saudi_arabia = Country.find_by_name('Saudi Arabia')
  City.create(city.merge!(country: @saudi_arabia))
end

puts "SKUs Seed"
SmarterCSV.process("db/seeds/skus.csv").each do |sku|
  @merchant = User.where(role: 2).first
  Sku.create(sku.merge!(merchant_id: @merchant.id))
end
