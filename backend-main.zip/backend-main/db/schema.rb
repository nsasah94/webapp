# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.0].define(version: 2023_03_21_082430) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "active_storage_attachments", force: :cascade do |t|
    t.string "name", null: false
    t.string "record_type", null: false
    t.bigint "record_id", null: false
    t.bigint "blob_id", null: false
    t.datetime "created_at", null: false
    t.index ["blob_id"], name: "index_active_storage_attachments_on_blob_id"
    t.index ["record_type", "record_id", "name", "blob_id"], name: "index_active_storage_attachments_uniqueness", unique: true
  end

  create_table "active_storage_blobs", force: :cascade do |t|
    t.string "key", null: false
    t.string "filename", null: false
    t.string "content_type"
    t.text "metadata"
    t.string "service_name", null: false
    t.bigint "byte_size", null: false
    t.string "checksum"
    t.datetime "created_at", null: false
    t.index ["key"], name: "index_active_storage_blobs_on_key", unique: true
  end

  create_table "active_storage_variant_records", force: :cascade do |t|
    t.bigint "blob_id", null: false
    t.string "variation_digest", null: false
    t.index ["blob_id", "variation_digest"], name: "index_active_storage_variant_records_uniqueness", unique: true
  end

  create_table "addresses", force: :cascade do |t|
    t.string "name"
    t.bigint "city_id", null: false
    t.text "maps_url"
    t.integer "address_type"
    t.boolean "elevator"
    t.boolean "parking"
    t.integer "floor"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "addressable_type"
    t.bigint "addressable_id"
    t.float "latitude"
    t.float "longitude"
    t.index ["addressable_type", "addressable_id"], name: "index_addresses_on_addressable"
    t.index ["city_id"], name: "index_addresses_on_city_id"
  end

  create_table "app_settings", force: :cascade do |t|
    t.string "key", null: false
    t.text "value", null: false
    t.float "version", default: 1.0, null: false
    t.float "build", default: 1.0, null: false
    t.integer "status", default: 0, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "cities", force: :cascade do |t|
    t.string "uuid"
    t.string "name"
    t.string "nameLocale"
    t.float "latitude"
    t.float "longitude"
    t.integer "dialcode"
    t.boolean "active"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "country_id", null: false
    t.index ["country_id"], name: "index_cities_on_country_id"
  end

  create_table "comments", force: :cascade do |t|
    t.text "body"
    t.integer "author_id"
    t.string "commentable_type", null: false
    t.bigint "commentable_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["commentable_type", "commentable_id"], name: "index_comments_on_commentable"
  end

  create_table "countries", force: :cascade do |t|
    t.string "name"
    t.string "nameLocale"
    t.boolean "active"
    t.float "vat"
    t.integer "dialcode"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "delivery_methods", force: :cascade do |t|
    t.string "name"
    t.string "key"
    t.boolean "is_active"
    t.integer "manifest_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "inventories", force: :cascade do |t|
    t.bigint "manifest_sku_id", null: false
    t.integer "layout_location_id"
    t.float "quantity"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "storage_unit"
    t.string "identifier"
    t.date "expiry_date"
    t.integer "storage_quantity"
    t.integer "number_of_pallets", default: 0
    t.integer "manifest_id"
    t.integer "merchant_id"
    t.integer "sku_id"
    t.integer "outbound_id"
    t.integer "condition"
    t.float "boxes_per_pallet"
    t.float "items_per_boxes"
    t.integer "deducted_boxes", default: 0
    t.index ["layout_location_id"], name: "index_inventories_on_layout_location_id"
    t.index ["manifest_sku_id"], name: "index_inventories_on_manifest_sku_id"
  end

  create_table "layout_aisles", force: :cascade do |t|
    t.string "identifier"
    t.bigint "warehouse_layout_id", null: false
    t.string "name"
    t.integer "bays"
    t.integer "levels"
    t.integer "locations"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["warehouse_layout_id"], name: "index_layout_aisles_on_warehouse_layout_id"
  end

  create_table "layout_bays", force: :cascade do |t|
    t.string "identifier"
    t.bigint "warehouse_layout_id", null: false
    t.bigint "layout_aisle_id", null: false
    t.string "name"
    t.integer "levels"
    t.integer "locations"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["layout_aisle_id"], name: "index_layout_bays_on_layout_aisle_id"
    t.index ["warehouse_layout_id"], name: "index_layout_bays_on_warehouse_layout_id"
  end

  create_table "layout_levels", force: :cascade do |t|
    t.string "identifier"
    t.bigint "warehouse_layout_id", null: false
    t.bigint "layout_aisle_id", null: false
    t.bigint "layout_bay_id", null: false
    t.string "name"
    t.integer "locations"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["layout_aisle_id"], name: "index_layout_levels_on_layout_aisle_id"
    t.index ["layout_bay_id"], name: "index_layout_levels_on_layout_bay_id"
    t.index ["warehouse_layout_id"], name: "index_layout_levels_on_warehouse_layout_id"
  end

  create_table "layout_locations", force: :cascade do |t|
    t.string "identifier"
    t.bigint "warehouse_layout_id", null: false
    t.bigint "layout_aisle_id", null: false
    t.bigint "layout_level_id", null: false
    t.string "name"
    t.integer "storage_unit"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "full_name"
    t.boolean "is_pickable", default: false
    t.index ["layout_aisle_id"], name: "index_layout_locations_on_layout_aisle_id"
    t.index ["layout_level_id"], name: "index_layout_locations_on_layout_level_id"
    t.index ["warehouse_layout_id"], name: "index_layout_locations_on_warehouse_layout_id"
  end

  create_table "magic_links", force: :cascade do |t|
    t.string "token"
    t.datetime "expires_at"
    t.bigint "user_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_magic_links_on_user_id"
  end

  create_table "manifest_skus", force: :cascade do |t|
    t.bigint "manifest_id", null: false
    t.bigint "sku_id", null: false
    t.integer "packaging"
    t.float "quantity"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.date "expiry_date"
    t.boolean "loose_container", default: false
    t.boolean "palletized", default: false
    t.integer "container_size_ft", default: 0
    t.integer "total_pallets", default: 0
    t.integer "total_sqm", default: 0
    t.integer "total_wrapping", default: 0
    t.integer "total_segregation", default: 0
    t.integer "total_wooden_pallets", default: 0
    t.float "quantity_per_package"
    t.float "sku_price"
    t.datetime "sku_expiry"
    t.float "loose_sqm"
    t.integer "storage_unit"
    t.integer "condition"
    t.float "storage_quantity"
    t.float "quantity_per_box"
    t.index ["manifest_id"], name: "index_manifest_skus_on_manifest_id"
    t.index ["sku_id"], name: "index_manifest_skus_on_sku_id"
  end

  create_table "manifests", force: :cascade do |t|
    t.string "identifier"
    t.integer "status"
    t.integer "manifest_type"
    t.integer "origin_id"
    t.integer "destination_id"
    t.integer "merchant_id"
    t.datetime "schedule_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "carrier_id"
  end

  create_table "outbound_inventories", force: :cascade do |t|
    t.integer "inventory_id"
    t.integer "outbound_id"
    t.integer "outbound_sku_id"
    t.float "quantity"
    t.integer "packaging"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "layout_location_id"
  end

  create_table "outbound_skus", force: :cascade do |t|
    t.integer "outbound_id"
    t.integer "sku_id"
    t.float "quantity"
    t.integer "packaging"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "inventory_id"
  end

  create_table "outbounds", force: :cascade do |t|
    t.string "identifier"
    t.integer "origin_id"
    t.integer "destination_id"
    t.jsonb "inventories"
    t.integer "carrier_id"
    t.integer "user_id"
    t.integer "status"
    t.datetime "schedule_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "prepared_by"
    t.integer "vehicle_type"
    t.integer "delivery_type"
    t.float "cost_of_trip"
  end

  create_table "products", force: :cascade do |t|
    t.string "identifier"
    t.string "upc"
    t.string "name"
    t.text "description"
    t.integer "has_expiry", default: 1
    t.integer "has_serial", default: 1
    t.integer "fragile", default: 1
    t.integer "merchant_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "sku_groups", force: :cascade do |t|
    t.string "name"
    t.integer "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "sku_groups_users", id: :serial, force: :cascade do |t|
    t.bigint "user_id", null: false
    t.bigint "sku_group_id", null: false
  end

  create_table "sku_sku_groups", force: :cascade do |t|
    t.integer "sku_id"
    t.integer "sku_group_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "skus", force: :cascade do |t|
    t.string "system_sku"
    t.string "merchant_sku"
    t.string "color"
    t.string "size"
    t.string "lot_no"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "sku_number"
    t.string "name"
    t.boolean "is_expiry"
    t.string "upc"
    t.integer "merchant_id"
    t.string "brand"
    t.float "value", default: 0.0
    t.integer "storage_type"
  end

  create_table "user_employees", force: :cascade do |t|
    t.integer "user_id"
    t.integer "employee_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "user_suppliers", force: :cascade do |t|
    t.integer "user_id"
    t.integer "supplier_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "user_warehouses", force: :cascade do |t|
    t.bigint "user_id"
    t.bigint "warehouse_id"
    t.integer "role"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_user_warehouses_on_user_id"
    t.index ["warehouse_id"], name: "index_user_warehouses_on_warehouse_id"
  end

  create_table "users", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "firstname"
    t.string "lastname"
    t.integer "phone"
    t.integer "mobile"
    t.string "company"
    t.string "vat_no"
    t.integer "role"
    t.integer "status"
    t.string "cr_no"
    t.integer "country_id"
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
  end

  create_table "warehouse_layouts", force: :cascade do |t|
    t.bigint "warehouse_id", null: false
    t.string "identifier"
    t.string "name"
    t.integer "aisles"
    t.integer "bays"
    t.integer "levels"
    t.integer "locations"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "storage_type"
    t.integer "storage_unit"
    t.index ["warehouse_id"], name: "index_warehouse_layouts_on_warehouse_id"
  end

  create_table "warehouses", force: :cascade do |t|
    t.string "identifier"
    t.string "name"
    t.string "maps_url"
    t.float "latitude"
    t.float "longitude"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "warehouse_type", default: 0
    t.boolean "has_fulfillment"
    t.boolean "has_sqm_storage"
    t.boolean "has_pallet_segregation"
    t.boolean "has_loose_container_unloading"
    t.boolean "has_packaging"
    t.boolean "has_pallet_storage"
    t.boolean "has_palletization"
    t.boolean "has_wrapping"
    t.boolean "has_wooden_pallets"
    t.float "area"
    t.integer "status", default: 0
  end

  add_foreign_key "active_storage_attachments", "active_storage_blobs", column: "blob_id"
  add_foreign_key "active_storage_variant_records", "active_storage_blobs", column: "blob_id"
  add_foreign_key "addresses", "cities"
  add_foreign_key "cities", "countries"
  add_foreign_key "inventories", "layout_locations"
  add_foreign_key "inventories", "manifest_skus"
  add_foreign_key "layout_aisles", "warehouse_layouts"
  add_foreign_key "layout_bays", "layout_aisles"
  add_foreign_key "layout_bays", "warehouse_layouts"
  add_foreign_key "layout_levels", "layout_aisles"
  add_foreign_key "layout_levels", "layout_bays"
  add_foreign_key "layout_levels", "warehouse_layouts"
  add_foreign_key "layout_locations", "layout_aisles"
  add_foreign_key "layout_locations", "layout_levels"
  add_foreign_key "layout_locations", "warehouse_layouts"
  add_foreign_key "magic_links", "users"
  add_foreign_key "manifest_skus", "manifests"
  add_foreign_key "manifest_skus", "skus"
  add_foreign_key "warehouse_layouts", "warehouses"
end
