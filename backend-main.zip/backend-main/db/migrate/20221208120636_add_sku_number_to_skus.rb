class AddSkuNumberToSkus < ActiveRecord::Migration[7.0]
  def change
    add_column :skus, :sku_number, :string
    remove_column :skus, :expiry
    remove_column :skus, :good_qty
    remove_column :skus, :bad_qty
    remove_column :skus, :missing_qty
    remove_column :skus, :product_id
  end
end
