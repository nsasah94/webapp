class AddCountsToInventories < ActiveRecord::Migration[7.0]
  def change
    add_column :inventories, :boxes_per_pallet, :float
    add_column :inventories, :items_per_boxes, :float
  end
end
