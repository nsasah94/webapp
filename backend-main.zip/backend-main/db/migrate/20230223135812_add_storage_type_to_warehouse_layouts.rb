class AddStorageTypeToWarehouseLayouts < ActiveRecord::Migration[7.0]
  def change
    add_column :warehouse_layouts, :storage_type, :integer
  end
end
