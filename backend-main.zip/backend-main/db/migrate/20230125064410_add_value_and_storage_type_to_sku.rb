class AddValueAndStorageTypeToSku < ActiveRecord::Migration[7.0]
  def change
    add_column :skus, :value, :float, default: 0
    add_column :skus, :storage_type, :integer
  end
end
