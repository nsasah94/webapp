class AddFieldsToOutbounds < ActiveRecord::Migration[7.0]
  def change
    add_column :outbounds, :prepared_by, :integer
    add_column :outbounds, :vehicle_type, :integer
    add_column :outbounds, :delivery_type, :integer
    add_column :outbounds, :cost_of_trip, :float
  end
end
