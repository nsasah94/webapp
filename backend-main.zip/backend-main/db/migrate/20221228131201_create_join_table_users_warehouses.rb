class CreateJoinTableUsersWarehouses < ActiveRecord::Migration[7.0]
  def change
    create_table :user_warehouses do |t|
      t.references :user
      t.references :warehouse

      t.integer :role
      t.timestamps
    end
  end
end
