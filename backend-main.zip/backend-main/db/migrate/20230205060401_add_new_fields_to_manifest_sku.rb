class AddNewFieldsToManifestSku < ActiveRecord::Migration[7.0]
  def change
    add_column :manifest_skus, :quantity_per_package, :float
    add_column :manifest_skus, :sku_price, :float
    add_column :manifest_skus, :sku_expiry, :datetime
    add_column :manifest_skus, :loose_sqm, :float
    add_column :manifest_skus, :storage_unit, :integer
    add_column :manifest_skus, :condition, :integer

    remove_column :manifest_skus, :good
    remove_column :manifest_skus, :damaged
    remove_column :manifest_skus, :missing
  end
end
