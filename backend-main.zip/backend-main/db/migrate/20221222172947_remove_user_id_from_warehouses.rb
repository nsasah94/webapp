class RemoveUserIdFromWarehouses < ActiveRecord::Migration[7.0]
  def change
    remove_column :warehouses, :user_id
  end
end
