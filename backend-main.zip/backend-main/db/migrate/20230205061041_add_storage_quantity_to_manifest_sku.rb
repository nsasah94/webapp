class AddStorageQuantityToManifestSku < ActiveRecord::Migration[7.0]
  def change
    add_column :manifest_skus, :storage_quantity, :float
  end
end
