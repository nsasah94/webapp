class CreateSkus < ActiveRecord::Migration[7.0]
  def change
    create_table :skus do |t|
      t.string :system_sku
      t.string :merchant_sku
      t.references :product, null: false, foreign_key: true
      t.string :color
      t.string :size
      t.string :lot_no
      t.date :expiry
      t.decimal :good_qty
      t.decimal :bad_qty
      t.decimal :missing_qty

      t.timestamps
    end
  end
end
