class AddExpiryDateToInventories < ActiveRecord::Migration[7.0]
  def change
    add_column :inventories, :expiry_date, :date
    add_column :inventories, :storage_quantity, :integer
    add_column :inventories, :number_of_pallets, :integer, default: 0
  end
end
