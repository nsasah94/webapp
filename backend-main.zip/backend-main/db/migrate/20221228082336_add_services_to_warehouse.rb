class AddServicesToWarehouse < ActiveRecord::Migration[7.0]
  def change
    add_column :warehouses, :has_fulfillment, :boolean
    add_column :warehouses, :has_sqm_storage, :boolean
    add_column :warehouses, :has_pallet_segregation, :boolean
    add_column :warehouses, :has_loose_container_unloading, :boolean
    add_column :warehouses, :has_packaging, :boolean
    add_column :warehouses, :has_pallet_storage, :boolean
    add_column :warehouses, :has_palletization, :boolean
    add_column :warehouses, :has_wrapping, :boolean
    add_column :warehouses, :has_wooden_pallets, :boolean
  end
end
