class AddIdToSkuGroupsUsers < ActiveRecord::Migration[7.0]
  def change
    add_column :sku_groups_users, :id, :integer, primary_key: true
  end
end
