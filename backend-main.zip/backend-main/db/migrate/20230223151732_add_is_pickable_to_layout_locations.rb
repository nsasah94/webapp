class AddIsPickableToLayoutLocations < ActiveRecord::Migration[7.0]
  def change
    add_column :layout_locations, :is_pickable, :boolean, default: false
  end
end
