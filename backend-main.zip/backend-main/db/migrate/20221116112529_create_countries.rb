class CreateCountries < ActiveRecord::Migration[7.0]
  def change
    create_table :countries do |t|
      t.string :name
      t.string :nameLocale
      t.boolean :active
      t.float :vat
      t.integer :dialcode

      t.timestamps
    end
  end
end
