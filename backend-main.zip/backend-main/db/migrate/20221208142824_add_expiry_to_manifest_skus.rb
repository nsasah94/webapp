class AddExpiryToManifestSkus < ActiveRecord::Migration[7.0]
  def change
    add_column :manifest_skus, :expiry_date, :date
  end
end
