class AddOutboundIdToInventory < ActiveRecord::Migration[7.0]
  def change
    add_column :inventories, :outbound_id, :integer
  end
end
