class CreateCities < ActiveRecord::Migration[7.0]
  def change
    create_table :cities do |t|
      t.string :uuid
      t.string :name
      t.string :nameLocale
      t.float :latitude
      t.float :longitude
      t.integer :dialcode
      t.boolean :active

      t.timestamps
    end
  end
end
