class CreateOutboundSkus < ActiveRecord::Migration[7.0]
  def change
    create_table :outbound_skus do |t|
      t.integer :outbound_id
      t.integer :sku_id
      t.float :quantity
      t.integer :packaging

      t.timestamps
    end
  end
end
