class AddQuantityPerBoxToManifestSkus < ActiveRecord::Migration[7.0]
  def change
    add_column :manifest_skus, :quantity_per_box, :float
  end
end
