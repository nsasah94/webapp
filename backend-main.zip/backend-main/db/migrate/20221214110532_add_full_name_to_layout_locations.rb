class AddFullNameToLayoutLocations < ActiveRecord::Migration[7.0]
  def change
    add_column :layout_locations, :full_name, :string
  end
end
