class CreateProducts < ActiveRecord::Migration[7.0]
  def change
    create_table :products do |t|
      t.string :identifier
      t.string :upc
      t.string :name
      t.text :description
      t.integer :has_expiry, default: 1
      t.integer :has_serial, default: 1
      t.integer :fragile, default: 1
      t.integer :merchant_id, null: false, foreign_key: true

      t.timestamps
    end
  end
end
