class AddNameToUsers < ActiveRecord::Migration[7.0]
  def change
    add_column :users, :firstname, :string
    add_column :users, :lastname, :string
    add_column :users, :phone, :integer
    add_column :users, :mobile, :integer
    add_column :users, :company, :string
    add_column :users, :vat_no, :string
    add_column :users, :role, :integer
    add_column :users, :status, :integer
    add_column :users, :cr_no, :string
    add_column :users, :country_id, :integer
  end
end
