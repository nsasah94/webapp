class CreateManifestSkus < ActiveRecord::Migration[7.0]
  def change
    create_table :manifest_skus do |t|
      t.references :manifest, null: false, foreign_key: true
      t.references :sku, null: false, foreign_key: true
      t.integer :packaging
      t.float :quantity
      t.float :good
      t.float :damaged
      t.float :missing

      t.timestamps
    end
  end
end
