class CreateLayoutLevels < ActiveRecord::Migration[7.0]
  def change
    create_table :layout_levels do |t|
      t.string :identifier
      t.references :warehouse_layout, null: false, foreign_key: true
      t.references :layout_aisle, null: false, foreign_key: true
      t.references :layout_bay, null: false, foreign_key: true
      t.string :name
      t.integer :locations

      t.timestamps
    end
  end
end
