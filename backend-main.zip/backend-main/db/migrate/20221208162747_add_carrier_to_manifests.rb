class AddCarrierToManifests < ActiveRecord::Migration[7.0]
  def change
    add_column :manifests, :carrier, :integer
  end
end
