class AddInventoryIdToOutboundSkus < ActiveRecord::Migration[7.0]
  def change
    add_column :outbound_skus, :inventory_id, :integer
  end
end
