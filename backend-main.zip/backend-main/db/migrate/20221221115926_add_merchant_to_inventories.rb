class AddMerchantToInventories < ActiveRecord::Migration[7.0]
  def change
    add_column :inventories, :manifest_id, :integer
    add_column :inventories, :merchant_id, :integer
    add_column :inventories, :sku_id, :integer
  end
end
