class ChangeNotNullOnInventories < ActiveRecord::Migration[7.0]
  def change
    change_column :inventories, :layout_location_id, :integer, null: true
  end
end
