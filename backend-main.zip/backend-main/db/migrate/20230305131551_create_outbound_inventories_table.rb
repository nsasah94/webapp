class CreateOutboundInventoriesTable < ActiveRecord::Migration[7.0]
  def change
    create_table :outbound_inventories do |t|
      t.integer :inventory_id
      t.integer :outbound_id
      t.integer :outbound_sku_id
      t.float :quantity
      t.integer :packaging

      t.timestamps
    end
  end
end
