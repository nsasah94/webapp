class ChangeDeductedBoxesDefault < ActiveRecord::Migration[7.0]
  def change
    change_column_default :inventories, :deducted_boxes, 0
  end
end
