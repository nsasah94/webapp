class CreateWarehouseLayouts < ActiveRecord::Migration[7.0]
  def change
    create_table :warehouse_layouts do |t|
      t.references :warehouse, null: false, foreign_key: true
      t.string :identifier
      t.string :name
      t.integer :aisles
      t.integer :bays
      t.integer :levels
      t.integer :locations

      t.timestamps
    end
  end
end
