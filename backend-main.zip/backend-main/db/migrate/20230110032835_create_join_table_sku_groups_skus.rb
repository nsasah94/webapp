class CreateJoinTableSkuGroupsSkus < ActiveRecord::Migration[7.0]
  def change
    create_table :sku_sku_groups do |t|
      t.integer :sku_id, foreign_key: true
      t.integer :sku_group_id, foreign_key: true

      t.timestamps
    end
  end
end
