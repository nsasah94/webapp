class RenameCarrierToCarrirerIdOnManfifests < ActiveRecord::Migration[7.0]
  def change
    rename_column :manifests, :carrier, :carrier_id
  end
end
