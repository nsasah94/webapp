class CreateManifests < ActiveRecord::Migration[7.0]
  def change
    create_table :manifests do |t|
      t.string :identifier
      t.integer :status
      t.integer :manifest_type
      t.integer :origin_id
      t.integer :destination_id
      t.integer :merchant_id
      t.datetime :schedule_at

      t.timestamps
    end
  end
end
