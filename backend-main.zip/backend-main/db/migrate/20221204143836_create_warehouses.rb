class CreateWarehouses < ActiveRecord::Migration[7.0]
  def change
    create_table :warehouses do |t|
      t.string :identifier
      t.string :name
      t.references :user, null: false, foreign_key: true
      t.string :maps_url
      t.float :latitude
      t.float :longitude
      t.references :city, null: false, foreign_key: true

      t.timestamps
    end
  end
end
