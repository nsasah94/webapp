class AddPalletizedToManifessts < ActiveRecord::Migration[7.0]
  def change
    add_column :manifests, :palletized, :boolean, default: false
    add_column :manifests, :total_pallets, :integer, default: 0
    add_column :manifests, :total_sqm, :integer, default: 0
    add_column :manifests, :total_wrapping, :integer, default: 0
    add_column :manifests, :total_segregation, :integer, default: 0
    add_column :manifests, :total_wooden_pallets, :integer, default: 0
  end
end
