class AddFieldsToManifestSku < ActiveRecord::Migration[7.0]
  def change
    add_column :manifest_skus, :loose_container, :boolean, default: false
    add_column :manifest_skus, :palletized, :boolean, default: false
    add_column :manifest_skus, :container_size_ft, :integer, default: 0
    add_column :manifest_skus, :total_pallets, :integer, default: 0
    add_column :manifest_skus, :total_sqm, :integer, default: 0
    add_column :manifest_skus, :total_wrapping, :integer, default: 0
    add_column :manifest_skus, :total_segregation, :integer, default: 0
    add_column :manifest_skus, :total_wooden_pallets, :integer, default: 0

    remove_column :manifests, :palletized, :boolean, default: false
    remove_column :manifests, :total_pallets, :integer, default: 0
    remove_column :manifests, :total_sqm, :integer, default: 0
    remove_column :manifests, :total_wrapping, :integer, default: 0
    remove_column :manifests, :total_segregation, :integer, default: 0
    remove_column :manifests, :total_wooden_pallets, :integer, default: 0
  end
end
