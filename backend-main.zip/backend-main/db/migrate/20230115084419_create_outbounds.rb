class CreateOutbounds < ActiveRecord::Migration[7.0]
  def change
    create_table :outbounds do |t|
      t.string :identifier
      t.integer :origin_id
      t.integer :destination_id
      t.jsonb :inventories
      t.integer :carrier_id
      t.integer :user_id
      t.integer :status
      t.datetime :schedule_at

      t.timestamps
    end
  end
end
