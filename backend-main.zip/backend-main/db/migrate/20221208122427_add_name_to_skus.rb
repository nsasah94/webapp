class AddNameToSkus < ActiveRecord::Migration[7.0]
  def change
    add_column :skus, :name, :string
    add_column :skus, :is_expiry, :boolean
    add_column :skus, :upc, :string
  end
end
