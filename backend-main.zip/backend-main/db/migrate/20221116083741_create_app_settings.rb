class CreateAppSettings < ActiveRecord::Migration[7.0]
  def change
    create_table :app_settings do |t|
      t.string :key, null: false
      t.text :value, null: false
      t.float :version, default: 1.0, null: false
      t.float :build, default: 1.0, null: false
      t.integer :status, default: 0, null: false

      t.timestamps
    end
  end
end
