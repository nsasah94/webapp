#!/bin/bash
# delete server.pid
(find . -name "server.pid" -delete)
#docker system prune &&
docker image prune &&
#docker container prune &&
#$(aws ecr get-login --no-include-email --region me-south-1)
$(aws ecr get-login --no-include-email --region eu-central-1)
# Deploy Latest Task to the Cluster
#$(aws ecs update-service --cluster DevCluster --service BackendService --force-new-deployment --region eu-central-1)

#$(aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws/i2i9s4o1)
docker-compose build &&
docker-compose push

aws ecs update-service --cluster DevCluster --service BackendService --force-new-deployment --region eu-central-1 --desired-count 2
aws ecs update-service --cluster ProdCluster --service ProductionService --force-new-deployment --region eu-central-1 --desired-count 2
