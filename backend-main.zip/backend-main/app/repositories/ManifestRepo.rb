class ManifestRepo
  attr_accessor :current_user

  def initialize(current_user)
    @current_user = current_user
  end

  def find(id)
    case current_user.role
    when "admin"
      Manifest.where(id: id).first
    when 'merchant'
      Manifest.where(id: id, merchant_id: current_user.id).first
    end
  end

  def all
    case current_user.role
    when "admin"
      Manifest.order(updated_at: :desc).reorder(status: :asc).all
    when 'merchant'
      Manifest.where(merchant_id: current_user.id).order(updated_at: :desc).reorder(status: :asc).all
    end
  end

end
