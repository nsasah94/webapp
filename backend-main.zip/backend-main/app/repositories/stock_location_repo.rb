class StockLocationRepo
  attr_accessor :current_user

  def initialize(current_user)
    @current_user = current_user
  end

  def find(id)
    case current_user.role
    when "admin"
      LayoutLocation.where(id: id).first
    when 'merchant'
      LayoutLocation.where(id: id).first
    end
  end

  def all
    case current_user.role
    when "admin"
      LayoutLocation.all
    when 'merchant'
      LayoutLocation.all
    end
  end

  def available_locations(warehouse_id:)
    warehouse_layouts = WarehouseLayout.where(warehouse_id: warehouse_id).pluck(:id)
    LayoutLocation.includes(:inventories, :warehouse_layout, :layout_aisle, :layout_bay, :layout_level)
                  .where(warehouse_layout_id: warehouse_layouts)
                  .where.not(id: Inventory.where(quantity: 1)
                                          .where.not('deducted_boxes = boxes_per_pallet')
                                          .pluck(:layout_location_id)).order(id: :asc)
  end
end
