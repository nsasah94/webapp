class UserRepo
  attr_accessor :current_user
  def initialize(current_user)
    @current_user = current_user
  end

  def find(id)
    case current_user.role
    when "admin"
      User.where(id: id).first
    else
      User.where(id: id, user_id: current_user.id).first
    end
  end

  def all
    case current_user.role
    when "admin"
      User.all
    else
      User.where(user_id: current_user.id).all
    end
  end
end

