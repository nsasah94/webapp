class WarehouseLayoutRepo
  attr_accessor :current_user

  def initialize(current_user)
    @current_user = current_user
  end

  def find(id)
    case current_user.role
    when "admin"
      WarehouseLayout.includes(:warehouse, layout_locations: [:inventories]).where(id: id).first
    else
      WarehouseLayout.includes(:warehouse, layout_locations: [:inventories])
                     .where(id: id)
                     .where(warehouse: { user_id: current_user.id }).first
    end
  end

  def all
    case current_user.role
    when "admin"
      WarehouseLayout.includes(:warehouse, :layout_locations).all
    else
      WarehouseLayout.includes(:warehouse, :layout_locations)
                     .where(warehouse: { user_id: current_user.id }).all
    end
  end
end
