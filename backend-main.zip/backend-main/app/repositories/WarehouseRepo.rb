class WarehouseRepo
  attr_accessor :current_user

  def initialize(current_user)
    @current_user = current_user
  end

  # Return a warehouse by ID that belongs to the current user.
  def find(id)
    case current_user.role
    when "admin"
      Warehouse.includes(:address, :layout_locations, :users).where(id: id).first
    else
      @current_user.warehouses.joins(:layout_locations, :inventories).where(id: id).first
    end
  end

  def all
    case current_user.role
    when "admin"
      Warehouse.includes(:address, :layout_locations, :users).all
    else
      @current_user.warehouses.all
      # Warehouse.includes(:address).where(user_id: current_user.id).all
    end
  end
end
