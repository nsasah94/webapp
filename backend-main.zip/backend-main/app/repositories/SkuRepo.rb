class SkuRepo
  attr_accessor :current_user

  def initialize(current_user)
    @current_user = current_user
  end

  def find(id)
    case current_user.role
    when 'admin'
      Sku.find(id)
    when 'merchant'
      Sku.where(id: id, merchant_id: current_user.id).first
    end
  end

  def all
    case current_user.role
    when 'admin'
      Sku.all
    when 'merchant'
      Sku.where(merchant_id: current_user.id).all
    end
  end

end
