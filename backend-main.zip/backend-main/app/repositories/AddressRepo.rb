class AddressRepo
  attr_accessor :current_user
  def initialize(current_user)
    @current_user = current_user
  end

  def find(id)
    case current_user.role
    when "admin"
      Address.where(id: id).first
    else
      Address.where(id: id, user_id: current_user.id).first
    end
  end

  def all
    case current_user.role
    when "admin"
      merchants_ids = User.where(role: :merchant).pluck(:id)
      suppliers_ids = User.where(role: :supplier).pluck(:id)
      warehouses_ids = Warehouse.pluck(:id)

      warehouses_addresses_ids = Address.where(addressable_id: warehouses_ids, addressable_type: 'Warehouse').pluck(:id)
      merchants_addresses_ids = Address.where(addressable_id: merchants_ids, addressable_type: 'User').pluck(:id)


      Address.where(id: warehouses_addresses_ids.concat(merchants_addresses_ids))
             .order(addressable_type: :desc)
             .all
    else
      addresses = []
      addresses << User.includes(:addresses, :suppliers).find(current_user.id)&.suppliers&.collect(&:addresses)&.flatten
      addresses << User.includes(:addresses, :suppliers, :warehouses).find(current_user.id)&.warehouses&.collect(&:address)&.flatten
      # addresses << current_user.suppliers.map(&:addresses).flatten # Get Suppliers Addresses
      # addresses << current_user.warehouses.map(&:address).flatten # Get Warehouses Addresses
      addresses << current_user&.addresses # Get Warehouses Addresses
      return addresses.flatten
    end
  end

  def destinations
    case current_user.role
    when 'admin'
      merchants_ids = User.where(role: :merchant).pluck(:id)
      suppliers_ids = User.where(role: :supplier).pluck(:id)
      warehouses_ids = Warehouse.pluck(:id)

      warehouses_addresses_ids = Address.where(addressable_id: warehouses_ids, addressable_type: 'Warehouse').pluck(:id)
      merchants_addresses_ids = Address.where(addressable_id: merchants_ids, addressable_type: 'User').pluck(:id)


      Address.where(id: warehouses_addresses_ids.concat(merchants_addresses_ids))
             .order(addressable_type: :desc).all
    else
      user_warehouses = current_user.warehouses.pluck(:id)
      # user_suppliers = current_user.suppliers.pluck(:id)
      user_addresses = current_user.addresses.pluck(:id)

      warehouses_addresses_ids = Address.where(addressable_id: user_warehouses, addressable_type: 'Warehouse').pluck(:id)
      merchants_addresses_ids = Address.where(addressable_id: user_addresses, addressable_type: 'User').pluck(:id)

      Address.where(id: warehouses_addresses_ids.concat(merchants_addresses_ids))
             .order(addressable_type: :desc).all
    end
  end

  def origins
    case current_user.role
    when 'admin'
      merchants_ids = User.where(role: :merchant).pluck(:id)
      suppliers_ids = User.where(role: :supplier).pluck(:id)
      warehouses_ids = Warehouse.pluck(:id)

      warehouses_addresses_ids = Address.where(addressable_id: warehouses_ids, addressable_type: 'Warehouse').pluck(:id)
      merchants_addresses_ids = Address.where(addressable_id: merchants_ids, addressable_type: 'User').pluck(:id)
      suppliers_addresses_ids = Address.where(addressable_id: suppliers_ids, addressable_type: 'User').pluck(:id)


      Address.where(id: merchants_addresses_ids.concat(suppliers_addresses_ids))
             .order(addressable_type: :desc)
             .all
    else
      user_suppliers = current_user.suppliers.pluck(:id)
      user_addresses = current_user.addresses.pluck(:id)

      suppliers_addresses_ids = Address.where(addressable_id: user_suppliers, addressable_type: 'User').pluck(:id)


      Address.where(id: suppliers_addresses_ids.concat(user_addresses))
             .order(addressable_type: :desc)
             .all
    end
  end

end
