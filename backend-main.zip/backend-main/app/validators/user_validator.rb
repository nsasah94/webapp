class UserValidator < ActiveModel::Validator
  def validate(record)
    record.errors.add(:base, 'Must enter a valid email.') if record.email.empty?
    record.errors.add(:base, 'An account with this email already exists.') if email_uniqueness(record)
    record.errors.add(:base, 'First name can not be blank.') if record.firstname.empty?
    record.errors.add(:base, 'Last name can not be empty.') if record.lastname.empty?
    unless record.admin?
      record.errors.add(:base, 'CR Number can not be empty.') if record.cr_no.empty?
      record.errors.add(:base, 'Company can not be empty.') if record.company.empty?
      record.errors.add(:base, 'VAT Number can not be empty.') if record.vat_no.empty?
    end
  end

  def email_uniqueness(record)
    User.where(email: record.email).exists?
  end

end
