class ManifestValidator < ActiveModel::Validator
  def validate(record)
    record.errors.add(:base, 'A Merchant must be associated with the manifest.') if record.merchant_id&.nil?
    record.errors.add(:base, 'Manifest type is not selected') if record.manifest_type&.nil?
    record.errors.add(:base, 'Origin/Destination can not be the same, use StockTransfer for internal stock movement.') if record.destination_id&.eql?(record.origin_id)
    record.errors.add(:base, 'Schedule date must be 2 days in advance and does not fall in weekends.') if (record.schedule_at.friday? || record.schedule_at.saturday?) && record.schedule_at >= (Time.current + 2.days.from_now)
  end
end
