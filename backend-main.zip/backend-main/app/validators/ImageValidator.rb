class ImageValidator < ActiveModel::Validator
  def validate(record)
    acceptable_image(record)
    record.errors[:base] << "File must be of type image"
  end

  private

  def acceptable_image(record)
    return true unless record.avatar.attached?
  end
end
