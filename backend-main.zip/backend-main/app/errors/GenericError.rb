class GenericError < StandardError
  attr_accessor :error_code, :error_status, :error_message

  def initialize(error_code: nil, error_status: nil, error_message: nil)
    @error_code = error_code
    @error_status = error_status
    @error_message = error_message
    super
  end
end
