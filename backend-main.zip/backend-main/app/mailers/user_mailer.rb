class UserMailer < ApplicationMailer
  default from: ENV['AWS_SES_DEFAULT_SENDER']

  def welcome_email
    @user = params[:user]
    @password = params[:password]
    @url  = "http://#{ENV['APP_DOMAIN']}/users/sign_in"
    mail(to: @user.email,
         subject: "#{ENV['APP_NAME']} Account Details",
         importance: 'High',
         'X-Priority' => '1')
  end
end
