class ManifestStatusMailer < ApplicationMailer
  default from: ENV['AWS_SES_DEFAULT_SENDER']

  def notify_user
    @type = params[:type]
    @user = params[:user]
    @record = params[:record]
    mail(to: @user.email,
         subject: "#{@type} Manifest #{@record.identifier} status changed to #{@record.status&.to_s&.titleize}",
         importance: 'High',
         'X-Priority' => '1')
  end
end
