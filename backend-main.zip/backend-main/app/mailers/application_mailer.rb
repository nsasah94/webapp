class ApplicationMailer < ActionMailer::Base
  default from: ENV['AWS_SES_DEFAULT_SENDER']
  layout "mailer"
end
