class OutboundCreatedMailer < ApplicationMailer
  default from: ENV['AWS_SES_DEFAULT_SENDER']

  def notify_user
    @user = params[:user]
    @record = params[:record]
    mail(to: @user.email,
         subject: "Outbound Manifest #{@record.identifier} Created",
         importance: 'High',
         'X-Priority' => '1')
  end
end
