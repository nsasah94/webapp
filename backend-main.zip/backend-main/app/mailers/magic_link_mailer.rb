class MagicLinkMailer < ApplicationMailer
  default from: ENV['AWS_SES_DEFAULT_SENDER']

  def sign_in_mail(email_link)
    @token = email_link.token
    @user = email_link.user

    mail(to: @user.email,
         subject: "Your account magic link! 🚀",
         importance: 'High',
         'X-Priority' => '1')
  end
end
