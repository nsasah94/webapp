class Employee::HomeController < DashboardController
  def index

  end
end
