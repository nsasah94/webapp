class Merchant::ManifestsController < DashboardController
  before_action :set_manifest, only: %i[ show edit update destroy cancel_manifest add_sku confirm ]

  # GET /manifests or /manifests.json
  def index
    @pagy, @manifests = pagy(ManifestRepo.new(current_user).all)
  end

  # GET /manifests/1 or /manifests/1.json
  def show
  end

  # GET /manifests/new
  def new
    @manifest = Manifest.new(carrier_id: params[:carrier_id])
    @manifest.schedule_at = (Time.now + 3.days).strftime('%-d/%-m/YYYY')
    @manifest.manifest_skus.build
    @destinations = AddressRepo.new(current_user).destinations
    @origins = AddressRepo.new(current_user).origins
    @addresses = AddressRepo.new(current_user).all
  end

  # GET /manifests/1/edit
  def edit
  end

  # POST /manifests or /manifests.json
  def create
    @manifest = Manifest.new(manifest_params)
    @manifest.merchant_id = current_user.id
    @record = ManifestService.new(@manifest, current_user).create_draft
    if @record
      redirect_to [:add_sku, current_user.role.to_sym, @manifest], success: "Manifest was successfully created."
    else
      render :new, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /manifests/1 or /manifests/1.json
  def update
    respond_to do |format|
      if @manifest.update(manifest_params)
        format.html { redirect_to [current_user.role.to_sym, @manifest], notice: "Manifest was successfully updated." }
        format.json { render :show, status: :ok, location: @manifest }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @manifest.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /manifests/1 or /manifests/1.json
  def destroy
    @manifest.destroy

    respond_to do |format|
      format.html { redirect_to [current_user.role.to_sym, :manifests], notice: "Manifest was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  def add_sku
    redirect_to [current_user.role.to_sym, @manifest], notice: 'This manifest can not be changed.' if !@manifest.draft?
    @manifest_sku = ManifestSku.new
  end

  def cancel_manifest
    @manifest = ManifestService.new(@manifest, current_user).cancel
    if @manifest
      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, :manifests], notice: "Manifest was cancelled successfully." }
        format.json { head :no_content }
      end
    end
  end

  def confirm
    if @manifest.manifest_skus.nil?
      respond_to do |format|
        format.html { redirect_to [:add_sku, current_user.role.to_sym, @manifest], notice: "Manifest does not have any SKUs." }
        format.json { head :no_content }
      end
    else
      @manifest.update(status: :created)
      NotificationManager::SlackNotifier.call(type: :manifest, manifest_id: @manifest.id)
      NotificationManager::EmailNotifier.call(type: :manifest, record_id: @manifest.id)
      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, @manifest], notice: "Manifest has been confirmed." }
        format.json { head :no_content }
      end
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_manifest
      @manifest = ManifestRepo.new(current_user).find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def manifest_params
      params.require(:manifest).permit(:identifier, :status, :manifest_type, :carrier_id,
                                       :origin_id, :destination_id, :schedule_at,
                                       :merchant_id, images: [],
                                       manifest_skus_attributes: [:sku_id, :packaging, :quantity, :expiry_date])
    end
end
