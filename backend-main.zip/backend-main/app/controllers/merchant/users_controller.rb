class Admin::UsersController < DashboardController
  before_action :set_user, only: %i[ show edit update destroy ]

  def index
    @users = UserRepo.new(current_user).all
  end

  def new
    @user = User.new
  end

  def edit
  end

  def show
  end

  def create
    password = SecureRandom.hex(4)
    @user = User.new(user_params.merge(password: password))

    respond_to do |format|
      if @user.save
        UserMailer.with(user: @user, password: password).welcome_email.deliver_now
        format.html { redirect_to [current_user.role.to_sym, @user, locale: I18n.locale], notice: "User was successfully created." }
        format.json { render :show, status: :created, location: @user }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @user.update(user_params)
        format.html { redirect_to [current_user.role.to_sym, @user], notice: "User was successfully updated." }
        format.json { render :show, status: :ok, location: @user }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  private

  def set_user
    @user = UserRepo.new(current_user).find(params[:id])
  end

  def user_params
    params.require(:user).permit(:firstname, :lastname, :email, :password, :vat_no, :cr_no, :company, :role, :status, :avatar)
  end
end
