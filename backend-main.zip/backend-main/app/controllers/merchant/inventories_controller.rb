class Merchant::InventoriesController < DashboardController
  before_action :set_inventory, only: %i[ show edit update destroy histories ]

  # GET /inventories or /inventories.json
  def index
    @inventories = Inventory.where(merchant_id: current_user.id)
                            .where(quantity: 1, outbound_id: nil)
                            .where('deducted_boxes < boxes_per_pallet')
                            .where.not('deducted_boxes = boxes_per_pallet')
                            .where.not(layout_location_id: nil)
                            .order(layout_location_id: :asc)
                            .order(created_at: :asc).all
  end

  # GET /inventories/1 or /inventories/1.json
  def show
    @pagy, @inventories = pagy(@inventory.sku.inventories
                                         .where(merchant_id: current_user.id, quantity: 1, outbound_id: nil)
                                         .where('deducted_boxes < ?', @inventory.boxes_per_pallet)
                                         .where.not('deducted_boxes = boxes_per_pallet')
                                         .order(layout_location_id: :asc)
                                         .order(created_at: :asc).all)

    @last_outbound = Outbound.includes(:outbound_inventories).where(outbound_inventories: { inventory_id: @inventories.pluck(:id)}).order(created_at: :desc)&.first
    @pagy_outbounds, @outbounds = pagy(Outbound.includes(:outbound_inventories).where(outbound_inventories: { inventory_id: @inventories.pluck(:id)}).where(status: 6).order(created_at: :desc).all)
  end

  def histories
    @inventories = @inventory.sku.inventories
                             .where(merchant_id: current_user.id, quantity: 1)
                             .where('deducted_boxes < ?', @inventory.boxes_per_pallet)
                             .order(layout_location_id: :asc)
                             .order(created_at: :asc).all

    @pagy, @outbounds = pagy(Outbound.includes(:outbound_inventories)
                                     .where(outbound_inventories: { inventory_id: @inventories.pluck(:id)})
                                     .where(status: 6)
                                     .order(created_at: :desc)
                                     .all)
  end

  # GET /inventories/new
  def new
    @inventory = Inventory.new
  end

  # GET /inventories/1/edit
  def edit
  end

  # POST /inventories or /inventories.json
  def create
    @inventory = Inventory.new(inventory_params)

    respond_to do |format|
      if @inventory.save
        format.html { redirect_to [current_user.role.to_sym, @inventory], notice: "Inventory was successfully created." }
        format.json { render :show, status: :created, location: @inventory }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @inventory.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /inventories/1 or /inventories/1.json
  def update
    respond_to do |format|
      if @inventory.update(inventory_params)
        format.html { redirect_to [current_user.role.to_sym, @inventory], notice: "Inventory was successfully updated." }
        format.json { render :show, status: :ok, location: @inventory }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @inventory.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy_modal
    respond_to do |format|
      format.js
    end
  end

  # DELETE /inventories/1 or /inventories/1.json
  def destroy
    if @inventory.layout_location_id.present?
      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, @inventory], error: "Oops! Can not delete inventory with associated location." }
        format.json { head :no_content }
      end
    else
      @inventory.destroy
      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, @inventory], notice: "Inventory was successfully removed." }
        format.json { head :no_content }
      end
    end
  end

  def assign_location
    location_id = params[:inventory][:layout_location_id]
    inventory_id = params[:inventory][:inventory_id]
    @inventory = Inventory.find(inventory_id)
    @updated = @inventory.update(layout_location_id: location_id)
    if @updated
      return redirect_to [current_user.role.to_sym, @inventory], notice: 'Inventory Location Updated.'
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_inventory
      @inventory = Inventory.includes(:manifest_sku, :sku, :merchant, :manifest, :layout_location).find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def inventory_params
      params.require(:inventory).permit(:manifest_sku_id, :layout_location_id, :quantity,
                                        :storage_type, :expiry_date, :packaging_type, :unit_quantity)
    end
end
