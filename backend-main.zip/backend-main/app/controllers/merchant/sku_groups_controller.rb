class Merchant::SkuGroupsController < DashboardController
  before_action :set_sku_group, only: [:update, :edit, :show, :destroy]

  def index
    @pagy, @sku_groups = pagy(SkuGroup.where(user_id: current_user.id).all)
  end

  def new
    @sku_group = SkuGroup.new
  end

  def create
    @sku_group = SkuGroup.new(sku_group_params)
    if @sku_group.save
      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, @sku_group], notice: "SKU Group created successfully." }
      end
    else
      respond_to do |format|
        format.html { redirect_to [:new, current_user.role.to_sym, :sku_group], notice: "An error occured while creating the skus group." }
      end
    end
  end

  def show
  end

  def update
  end

  def link_user_modal
    @sku_group = SkuGroup.find(params[:id])
    @employees = @sku_group.user.employees

    respond_to do |format|
      format.js
    end
  end

  def link_user
    @sku_group = SkuGroup.find(params[:id])
    if params[:sku_group][:user_id].present?
      user = User.find(params[:sku_group][:user_id])

      SkuGroupService.new(user, @sku_group, nil).attach_group

      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, @sku_group], notice: "User Linked Successfully." }
      end
    else
      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, @sku_group], notice: "Unable to Link the SKU without a User." }
      end
    end
  end

  def unlink_user
    user = User.find(params[:employee_id])
    @sku_group = SkuGroup.find(params[:id])

    SkuGroupService.new(user, @sku_group, nil).detach_group

    respond_to do |format|
      format.html { redirect_to [current_user.role.to_sym, @sku_group], notice: "User Unlinked Successfully." }
    end
  end

  def link_sku_modal

    @sku_group = SkuGroup.find(params[:id])
    @skus = SkuGroupService.new(@sku_group.user, nil, nil).skus

    respond_to do |format|
      format.js
    end
  end

  def link_sku
    @sku_group = SkuGroup.find(params[:id])
    @skus = Sku.where(id: params[:sku_group][:sku_id])

    @skus.each do |sku|
      SkuGroupService.new(nil, @sku_group, sku).attach_sku
    end

    respond_to do |format|
      format.html { redirect_to [current_user.role.to_sym, @sku_group], notice: "SKU Linked Successfully." }
    end
  end

  def unlink_sku
    @sku_group = SkuGroup.find(params[:id])
    @sku = Sku.find(params[:sku_id])

    SkuGroupService.new(nil, @sku_group, @sku).detach_sku

    respond_to do |format|
      format.html { redirect_to [current_user.role.to_sym, @sku_group], notice: "SKU Unlinked Successfully." }
    end
  end

  private

  def set_sku_group
    @sku_group = SkuGroup.find(params[:id])
  end

  def sku_group_params
    params.require(:sku_group).permit(:name, :user_id, :sku_id)
  end
end
