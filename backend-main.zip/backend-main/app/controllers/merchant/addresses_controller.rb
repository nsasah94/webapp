class Merchant::AddressesController < DashboardController
  before_action :set_address, only: %i[ show edit update destroy ]

  # GET /addresses or /addresses.json
  def index
    @addresses = AddressRepo.new(current_user).all
  end

  # GET /addresses/1 or /addresses/1.json
  def show
  end

  # GET /addresses/new
  def new
    @address = Address.new

  end

  # GET /addresses/1/edit
  def edit
  end

  # POST /addresses or /addresses.json
  def create
    @country = Country.first_or_create!(name: address_params[:country_name].to_s.strip)
    @city = City.first_or_create!(name: address_params[:city_name], country_id: @country.id)
    new_params = address_params.merge({city_id: @city.id})
    @merchant = current_user

    @address = Address.create(new_params.merge!({addressable: @merchant, addressable_type: 'User'}))

    respond_to do |format|
      if @address
        format.html { redirect_to [current_user.role.to_sym, :addresses], notice: "Address was successfully created." }
        format.json { render :show, status: :created, location: @address }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @address.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /addresses/1 or /addresses/1.json
  def update
    respond_to do |format|
      if @address.update(address_params)
        format.html { redirect_to [current_user.role.to_sym, @address], notice: "Address was successfully updated." }
        format.json { render :show, status: :ok, location: @address }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @address.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /addresses/1 or /addresses/1.json
  def destroy
    @address.destroy

    respond_to do |format|
      format.html { redirect_to [current_user.role.to_sym, :addresses], notice: "Address was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_address
      @address = AddressRepo.new(current_user).find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def address_params
      params.require(:address).permit(:maps_url, :address_type, :city_id, :name, :latitude, :longitude, :city_name, :country_name, :addressable, :user_id)
    end
end
