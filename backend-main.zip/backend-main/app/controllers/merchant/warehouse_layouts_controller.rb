class Admin::WarehouseLayoutsController < DashboardController
  before_action :set_warehouse_layout, only: %i[ show edit update destroy ]

  # GET /warehouse_layouts or /warehouse_layouts.json
  def index
    @warehouse_layouts = WarehouseLayoutRepo.new(current_user).all
  end

  # GET /warehouse_layouts/1 or /warehouse_layouts/1.json
  def show
  end

  # GET /warehouse_layouts/new
  def new
    @warehouse_layout = WarehouseLayout.new
  end

  # GET /warehouse_layouts/1/edit
  def edit
  end

  # POST /warehouse_layouts or /warehouse_layouts.json
  def create
    @warehouse_layout = WarehouseLayout.new(warehouse_layout_params)

    respond_to do |format|
      if @warehouse_layout.save
        format.html { redirect_to [current_user.role.to_sym, @warehouse_layout], notice: "Warehouse layout was successfully created." }
        format.json { render :show, status: :created, location: @warehouse_layout }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @warehouse_layout.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /warehouse_layouts/1 or /warehouse_layouts/1.json
  def update
    respond_to do |format|
      if @warehouse_layout.update(warehouse_layout_params)
        format.html { redirect_to [current_user.role.to_sym, @warehouse_layout], notice: "Warehouse layout was successfully updated." }
        format.json { render :show, status: :ok, location: @warehouse_layout }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @warehouse_layout.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /warehouse_layouts/1 or /warehouse_layouts/1.json
  def destroy
    @warehouse_layout.destroy

    respond_to do |format|
      format.html { redirect_to [current_user.role.to_sym, :warehouse_layouts], notice: "Warehouse layout was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_warehouse_layout
      @warehouse_layout = WarehouseLayoutRepo.new(current_user).find(params[:id])
      # @layout_preview = LayoutService.new(nil, Warehouse.last, WarehouseLayout.first).generate_aisles
    end

    # Only allow a list of trusted parameters through.
    def warehouse_layout_params
      params.require(:warehouse_layout).permit(:warehouse_id, :identifier, :name, :aisles, :bays, :levels, :locations)
    end
end
