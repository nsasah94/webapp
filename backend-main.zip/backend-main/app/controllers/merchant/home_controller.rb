class Merchant::HomeController < DashboardController
  def index

  end
end
