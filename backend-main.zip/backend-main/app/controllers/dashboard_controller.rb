class DashboardController < ApplicationController
  add_flash_types :info, :error, :success
  before_action :authenticate_user!
  layout 'dashboard'

  include Pagy::Backend

  before_action :set_breadcrumbs
  def set_breadcrumbs
    add_breadcrumb "<b>Dashboard</b>".html_safe, [current_user.role.to_sym, :root]
    if !controller_name.eql?('home')
      add_breadcrumb controller_name.camelcase, [current_user.role.to_sym, controller_name.to_sym]
      add_breadcrumb action_name.camelcase if !action_name.eql?('index')
    end

    if current_user.admin? && !request.path.include?('admin')
      return redirect_to admin_root_path
    elsif current_user.merchant? && !request.path.include?('merchant')
      return redirect_to merchant_root_path
    elsif current_user.employee? && !request.path.include?('employee')
      return redirect_to merchant_root_path
    elsif current_user.partner? && !request.path.include?('partner')
      return redirect_to partner_root_path
    else
      root_path
    end
  end

  private

  def role_template
    user_role = current_user.role
    "#{user_role}_#{action_name}"
  end
end
