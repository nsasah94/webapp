class ApplicationController < ActionController::Base
  rescue_from GenericError, with: :handle_exception

  before_action :prepare_exception_notifier
  before_action :set_locale
  before_action :check_user_role

  def default_url_options(options={})
    puts config.url_options
    { locale: I18n.locale.eql?(I18n.default_locale) ? I18n.default_locale : I18n.locale  }
  end

  def set_locale
    I18n.locale = extract_locale || I18n.default_locale
  end

  def switch_locale(&action)
    locale = params[:locale] || I18n.default_locale
    I18n.with_locale(locale, &action)
  end

  def extract_locale
    parsed_locale = params[:locale]
    I18n.available_locales.map(&:to_s).include?(parsed_locale) ? parsed_locale : nil
  end

  private

  def after_sign_in_path_for(resource)
    if resource.admin?
      admin_root_path
    elsif resource.merchant?
      merchant_root_path
    elsif resource.employee?
      merchant_root_path
    elsif resource.partner?
      partner_root_path
    else
      root_path
    end
  end

  def prepare_exception_notifier
    request.env["exception_notifier.exception_data"] = {
      current_user: current_user
    }
  end

  def handle_exception(error)
    flash[:danger] = "#{error.error_message} - Error Code #{error.error_code}"
    return redirect_back(fallback_location: root_path), locale: I18n.locale
  end

  def check_user_role
    # if current_user.admin? && request.path.include?('admin')
    #   admin_root_path
    # elsif current_user.merchant? && !request.path.include?('merchant')
    #   merchant_root_path
    # elsif current_user.employee?
    #   merchant_root_path
    # elsif current_user.partner?
    #   partner_root_path
    # else
    #   root_path
    # end
  end

end
