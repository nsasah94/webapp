class Admin::MerchantsController < DashboardController
  before_action :set_merchant, only: %i[ show edit update destroy ]
  def index
    @merchants = Merchant.all
  end

  def show
  end

  def set_merchant
    @merchant = Merchant.find(params[:id])
  end
end
