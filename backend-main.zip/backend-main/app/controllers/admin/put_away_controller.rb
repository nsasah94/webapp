class Admin::PutAwayController < DashboardController
  before_action :set_manifest, only: %i[show]


  def new
    @manifest_sku = ManifestSku.find(params[:id])
    respond_to do |format|
      # format.html
      format.js
    end
  end

  def show
  end

  private

  def set_manifest
    @manifest = Manifest.find(params[:id])
  end
end
