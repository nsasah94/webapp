class Admin::ProductsController < DashboardController
  before_action :set_product, only: %i[ show edit update destroy ]

  def index
    @products = Product.for_user(current_user)
  end

  def show
  end

  def new
    @product = Product.new
  end

  def create
    @product = Product.create!(product_params)
    respond_to do |format|
      if @product.save
        format.html { redirect_to [current_user.role.to_sym, @product, locale: I18n.locale], notice: "Product was successfully created." }
        format.json { render :show, status: :created, location: @product }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @product.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @product.update(product_params)
        format.html { redirect_to [current_user.role.to_sym, @product], notice: "Product was successfully updated." }
        format.json { render :show, status: :ok, location: @product }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @product.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @product.destroy

    respond_to do |format|
      format.html { redirect_to [current_user.role.to_sym, controller_name.to_sym], notice: "Product was successfully deleted." }
      format.json { head :no_content }
    end
  end

  private

  def set_product
    @product = Product.find(params[:id])
  end

  def product_params
    params.require(:product).permit(:identifier, :upc, :name, :description, :category, :has_expiry, :has_serial, :fragile, :merchant_id)
  end
end
