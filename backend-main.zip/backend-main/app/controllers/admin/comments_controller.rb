class Admin::CommentsController < ApplicationController

  def create
    puts params
    puts @commentable
  end

end
