class Admin::StockLocationsController < DashboardController
  before_action :set_stock_location, only: %i{ show edit update }

  def index
    locations = StockLocationRepo.new(current_user).all || LayoutLocation.none
    @pagy, @stock_locations = pagy(locations)
    filtering_params(params).each do |key, value|
      @pagy, @stock_locations = pagy(locations.public_send("filter_by_#{key}", value)) if value.present?
    end
  end

  def show
  end

  def assign_location
    @inventory = Inventory.find(params[:inventory_id])
    @last_selected = @inventory.sku.inventories&.where.not(layout_location_id: nil)&.last&.layout_location_id
    # Find Available Locations based on first inventory saved location
    # If the Location is A-2-B-1 the second should be A-2-B-2 even if previous locations are empty.
    # All Stocks should be stored next to each others.
    locations = StockLocationRepo.new(current_user).available_locations(warehouse_id: @inventory.manifest.destination.addressable_id)
    @available_locations = @last_selected.nil? ? locations.limit(250) : locations.where('layout_locations.id > ?', @last_selected).limit(250)
    respond_to do |format|
      format.js
    end
  end

  def stock_location_label
    @location = LayoutLocation.find(params[:id])
    pdf = LabelService.new(@location).generate_label
    send_data pdf.render,
              filename: "#{@location.identifier}.pdf",
              type: 'application/pdf',
              disposition: 'inline'
  end

  def new_generic_label
  end

  def generic_location_label
    pdf = LabelService.new.quick_locations(params[:layout][:aisles], params[:layout][:bays], params[:layout][:levels], params[:layout][:locations])
    send_data pdf.render,
              filename: "generic_labels.pdf",
              type: 'application/pdf',
              disposition: 'inline'
  end

  def edit
    @location = LayoutLocation.find(params[:id])
    respond_to do |format|
      format.js
    end
  end

  def update_location
    @location = LayoutLocation.find(params[:id])
    if @location.update(update_params)
      redirect_to [current_user.role.to_sym, :stock_locations], success: "Location updated successfully."
    else
      render :new, status: :unprocessable_entity
    end
  end

  private

  def set_stock_location
    @stock_location = StockLocationRepo.new(current_user).find(params[:id])
  end

  def filtering_params(params)
    params.slice(:type, :warehouse, :pickable, :storage_unit)
  end


end
