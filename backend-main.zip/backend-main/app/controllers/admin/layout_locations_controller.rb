class Admin::LayoutLocationsController < DashboardController
  def edit
  end

  def update_location
    @location = LayoutLocation.find(params[:id])
    if @location.update(is_pickable: update_params[:is_pickable],
                        storage_unit: update_params[:storage_unit])
      redirect_to [current_user.role.to_sym, :stock_locations], success: "Location updated successfully."
    else
      redirect_to [current_user.role.to_sym, :stock_locations], error: @location.errors.full_messages
    end
  end

  private

  def update_params
    params.require(:layout_location).permit(:is_pickable, :storage_unit)
  end
end
