class Admin::WarehousesController < DashboardController
  before_action :set_warehouse, only: %i[ show edit update destroy ]

  # GET /warehouses or /warehouses.json
  def index
    @pagy, @warehouses = pagy(WarehouseRepo.new(current_user).all)
    filtering_params(params).each do |key, value|
      @pagy, @warehouses = pagy(@warehouses.public_send("filter_by_#{key}", value)) if value.present?
    end
  end

  # GET /warehouses/1 or /warehouses/1.json
  def show
  end

  # GET /warehouses/new
  def new
    @warehouse = Warehouse.new
    @warehouse.address = Address.new

    @warehouse.address = Address.new
    @warehouse.address.latitude = 23.8859
    @warehouse.address.longitude = 45.0792

    respond_to do |format|
      format.html
    end
  end

  # GET /warehouses/1/edit
  def edit
  end

  # POST /warehouses or /warehouses.json
  def create
    @warehouse = Warehouse.new
    @warehouse_service = WarehouseService.new(@warehouse)
    @warehouse = @warehouse_service.create(params)

    respond_to do |format|
      if @warehouse.errors.blank?
        format.html {
          flash[:notice] = "Warehouse was successfully created."
          redirect_to [current_user.role.to_sym, @warehouse]
        }
        format.json { render :show, status: :created, location: @warehouse }
      else
        format.html {
          flash[:notice] = @warehouse.errors.full_messages.to_sentence
          render :new, status: :unprocessable_entity
        }
        format.json { render json: @warehouse.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /warehouses/1 or /warehouses/1.json
  def update
    @warehouse_service = WarehouseService.new(@warehouse)
    @warehouse = @warehouse_service.update(params)
    respond_to do |format|
      if @warehouse
        format.html { redirect_to [current_user.role.to_sym, @warehouse], notice: "Warehouse was successfully updated." }
        format.json { render :show, status: :ok, location: @warehouse }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @warehouse.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /warehouses/1 or /warehouses/1.json
  def destroy
    @warehouse.destroy

    respond_to do |format|
      format.html { redirect_to [current_user.role.to_sym, :warehouses], notice: "Warehouse was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  def add_merchants
    @warehouse = Warehouse.find(params[:id])
    @clients = Merchant.all
    puts params
  end

  def toggle_status
    @warehouse = Warehouse.find(params[:id])
    @warehouse.update(status: params[:status])
    respond_to do |format|
      format.html { redirect_to [current_user.role.to_sym, @warehouse], notice: "Warehouse deactivated." }
      format.json { head :no_content }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_warehouse
    @warehouse = WarehouseRepo.new(current_user).find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def warehouse_params
    params.require(:warehouse).permit(:identifier, :name, :user_id, :maps_url, :latitude, :longitude, :city_id, :warehouse_type,
                                      :has_fulfillment, :has_sqm_storage, :has_pallet_segregation, :has_has_loose_container_unloading,
                                      :has_packaging, :has_palletization, :has_wrapping, :has_wooden_pallets, :area, :status,
                                      address_attributes: [:city_name, :country_name, :name, :city_id, :address_type, :latitude, :longitude])
  end

  def filtering_params(params)
    params.slice(:status, :type, :city)
  end
end
