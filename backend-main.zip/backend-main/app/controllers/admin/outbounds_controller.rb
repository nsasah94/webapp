class Admin::OutboundsController < DashboardController
  before_action :set_outbound, only: %i[ show edit update destroy confirm cancel_outbound change_status print_picker_list attach_images remove_sku_from_outbound add_comment ]
  def index
    @pagy, @outbounds = pagy(Outbound.order(status: :asc).order(schedule_at: :desc).all)
    filtering_params(params).each do |key, value|
      @pagy, @outbounds = pagy(@outbounds.public_send("filter_by_#{key}", value)) if value.present?
    end
  end

  def new
    @outbound = Outbound.new
    @outbound.schedule_at = (Time.now + 3.days).strftime('%-d/%-m/YYYY')
    @outbound.status = :draft
    @delivery_methods = DeliveryMethod.where(manifest_type: :outbound).order(:name)
    @addresses = AddressRepo.new(current_user).all.where(addressable_type: :User)
  end

  def create
    destination_id = params[:outbound][:destination_id]
    user_id = current_user.admin? ? Address.find(destination_id).addressable.id : current_user.id

    if Sku.where(merchant_id: user_id).size.eql?(0)
      return redirect_to [current_user.role.to_sym, :outbounds], success: "You don't have any SKUs available yet, try creating an Inbound Manifest"
    end

    @outbound = Outbound.new(outbound_params.merge!({ user_id: user_id }))
    @addresses = AddressRepo.new(current_user).all.where(addressable_type: :User)

    raise GenericError.new(error_code: 'MNF-0002.5', error_status: 422, error_message: 'Date must be 1 day in advance') unless @outbound.schedule_at >= (Time.now + 1.day)

    # @record = OutboundService.new(current_user).availability_check

    if @outbound.save
      redirect_to [current_user.role.to_sym, @outbound], success: "Draft outbound manifest was successfully created."
    else
      render :new, status: :unprocessable_entity, notice: @outbound.errors
    end
  end

  def add_or_update_inventory
    @outbound = Outbound.find(params[:id])
    inventory_params = params[:outbound][:inventories]

    OutboundService.new.availability_check(inventory_params[:sku_id], inventory_params[:quantity], inventory_params[:packaging])

    @outbound.outbound_skus.create!(sku_id: inventory_params[:sku_id], quantity: inventory_params[:quantity], packaging: inventory_params[:packaging])

    if @outbound.save
      redirect_to [current_user.role.to_sym, @outbound], success: "Outbound manifest was successfully updated."
    else
      redirect_to [current_user.role.to_sym, @outbound], notice: @outbound.errors
    end
  end

  def update_inventory
    @outbound = Outbound.find(params[:id])

    @outbound_sku = OutboundSku.find(params[:outbound_skus][:id])

    @outbound_sku.quantity = params[:outbound_skus][:quantity]
    @outbound_sku.packaging = params[:outbound_skus][:packaging].to_i

    OutboundService.new.availability_check(@outbound_sku.sku_id, params[:outbound_skus][:quantity], params[:outbound_skus][:packaging])

    if params[:outbound_skus][:quantity].to_i < "1".to_i
      if @outbound_sku.destroy
        redirect_to [current_user.role.to_sym, @outbound], success: "Outbound SKU was successfully removed."
      else
        redirect_to [current_user.role.to_sym, @outbound], notice: @outbound_sku.errors
      end
    else
      if @outbound_sku.save
        redirect_to [current_user.role.to_sym, @outbound], success: "Outbound manifest SKU was successfully updated."
      else
        redirect_to [current_user.role.to_sym, @outbound], notice: @outbound_sku.errors
      end
    end
    # @outbound.outbound_skus.update!(sku_id: inventory_params[:sku_id], quantity: inventory_params[:quantity], packaging: inventory_params[:packaging])
  end

  def remove_sku_from_outbound
    @outbound = Outbound.find(params[:outbound_id])
    @outbound_sku = OutboundSku.find(params[:sku_id])
    if @outbound_sku.destroy
      redirect_to [current_user.role.to_sym, @outbound], success: "Outbound SKU was successfully removed."
    else
      redirect_to [current_user.role.to_sym, @outbound], notice: @outbound_sku.errors
    end
  end

  def remove_inventory
  end
  def confirm
    if @outbound.outbound_skus.nil?
      respond_to do |format|
        format.html { redirect_to [:add_sku, current_user.role.to_sym, @outbound], notice: "Outbound does not have any SKUs." }
        format.json { head :no_content }
      end
    else
      @outbound.update(status: :created)
      NotificationManager::SlackNotifier.call(type: :outbound, outbound_id: @outbound.id)
      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, @outbound], notice: "Outbound has been confirmed." }
        format.json { head :no_content }
      end
    end
  end

  def cancel_outbound
    @outbound = OutboundService.new(@outbound, current_user).cancel
    if @outbound
      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, :outbounds], notice: "Outbound Manifest was cancelled successfully." }
        format.json { head :no_content }
      end
    end
  end

  def change_status
    @outbound = OutboundService.new(@outbound, current_user).change_status(status: params[:status])
    if @outbound
      OutboundService.new(@outbound, current_user).update_inventory
      if @outbound.completed?
        NotificationManager::StatusNotifier.call(type: :outbound, record_id: @outbound.id)
      end
      redirect_to [current_user.role.to_sym, @outbound], success: "Outbound status changed successfully."
    else
      render :new, status: :unprocessable_entity
    end
  end

  def show
    @outbound = Outbound.find(params[:id])
  end

  def print_picker_list
    pdf = PickingService.new(@outbound).generate_label
    send_data pdf.render,
              filename: "#{@outbound.identifier}.pdf",
              type: 'application/pdf',
              disposition: 'inline'
  end

  def update_outbound
    @outbound = Outbound.find(params[:id])
    @prepared_by = User.find(update_params[:prepared_by])
    @updated = @outbound.update(prepared_by: @prepared_by,
                     vehicle_type: update_params[:vehicle_type],
                     delivery_type: update_params[:delivery_type],
                     cost_of_trip: update_params[:cost_of_trip])

    if @updated
      redirect_to [current_user.role.to_sym, @outbound], success: "Outbound updated successfully."
    else
      render :new, status: :unprocessable_entity
    end
  end

  def attach_images
    if @outbound.images.attach(params[:images])
      redirect_to [current_user.role.to_sym, @outbound], success: "Images Uploaded successfully"
    else
      render :new, status: :unprocessable_entity
    end
  end

  def add_comment
    @outbound.comments.create(comments_params.merge!(commentable: @outbound, author_id: current_user.id))
    redirect_to [current_user.role.to_sym, @outbound], notice: 'Comment Added.'
  end

  private

  def set_outbound
    @outbound = Outbound.find(params[:id])
  end

  def comments_params
    params.require(:comments).permit(:body)
  end

  def outbound_params
    params.require(:outbound).permit(:carrier_id, :origin_id, :destination_id, :schedule_at, :user_id, inventories_attributes: [:sku_id, :quantity, :id], outbound_skus_attributes: [:sku_id, :quantity, :id])
  end

  def update_params
    params.require(:outbound).permit(:prepared_by, :vehicle_type, :delivery_type, :cost_of_trip)
  end

  def filtering_params(params)
    params.slice(:status, :merchant, :carrier)
  end

end
