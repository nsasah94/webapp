class Admin::ManifestsController < DashboardController
  before_action :set_manifest, only: %i[ show edit update destroy confirm add_sku cancel_manifest change_status add_comment create_inventory attach_images ]

  # GET /manifests or /manifests.json
  def index
    @pagy, @manifests = pagy(ManifestRepo.new(current_user).all)
    filtering_params(params).each do |key, value|
      @pagy, @manifests = pagy(@manifests.public_send("filter_by_#{key}", value)) if value.present?
    end
  end

  # GET /manifests/1 or /manifests/1.json
  def show
  end

  # GET /manifests/new
  def new
    @manifest = Manifest.new
    @manifest.schedule_at = (Time.now + 1.day).strftime('%-d/%-m/YYYY')
    @manifest.manifest_skus.build
    @destinations = AddressRepo.new(current_user).destinations
    @origins = AddressRepo.new(current_user).origins
    @addresses = AddressRepo.new(current_user).all
  end

  # GET /manifests/1/edit
  def edit
    @manifest.schedule_at = @manifest.schedule_at.strftime('%-d/%-m/YYYY')
    @manifest.manifest_skus.build
    @addresses = AddressRepo.new(@manifest.merchant).all
  end

  # POST /manifests or /manifests.json
  def create
    @manifest = Manifest.new(manifest_params)
    @record = ManifestService.new(@manifest, current_user).create_draft
    if @record
      redirect_to [:add_sku, current_user.role.to_sym, @manifest], success: "Draft manifest was successfully created."
    else
      render :new, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /manifests/1 or /manifests/1.json
  def update
    respond_to do |format|
      if @manifest.update(manifest_params)
        format.html { redirect_to [current_user.role.to_sym, @manifest], notice: "Manifest was successfully updated." }
        format.json { render :show, status: :ok, location: @manifest }
      else
        format.html { redirect_to [:edit, current_user.role.to_sym, @manifest], notice: @manifest.errors.full_messages }
        # format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @manifest.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /manifests/1 or /manifests/1.json
  def destroy
    @manifest.destroy

    respond_to do |format|
      format.html { redirect_to [current_user.role.to_sym, :manifests], notice: "Manifest was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  def add_sku
    redirect_to [current_user.role.to_sym, @manifest], notice: 'This manifest can not be changed.' if !@manifest.editable?
    @manifest_sku = ManifestSku.new
  end

  def add_comment
    @manifest.comments.create(comments_params.merge!(commentable: @manifest, author_id: current_user.id))
    redirect_to [current_user.role.to_sym, @manifest], notice: 'Comment Added.'
  end

  def cancel_manifest
    @manifest = ManifestService.new(@manifest, current_user).cancel
    if @manifest
      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, :manifests], notice: "Manifest was cancelled successfully." }
        format.json { head :no_content }
      end
    end
  end

  def confirm
    if @manifest.manifest_skus.nil?
      respond_to do |format|
        format.html { redirect_to [:add_sku, current_user.role.to_sym, @manifest], notice: "Manifest does not have any SKUs." }
        format.json { head :no_content }
        end
    else
      @manifest.update(status: :created)
      NotificationManager::SlackNotifier.call(type: :manifest, manifest_id: @manifest.id)
      respond_to do |format|
        format.html { redirect_to [current_user.role.to_sym, @manifest], notice: "Manifest has been confirmed." }
        format.json { head :no_content }
      end
    end
  end

  def change_status
    @manifest = ManifestService.new(@manifest, current_user).change_status(status: params[:status])
    if @manifest
      redirect_to [current_user.role.to_sym, @manifest], success: "Manifest status changed successfully."
    else
      render :new, status: :unprocessable_entity
    end
  end

  def create_inbound
    @manifest_sku = ManifestSku.find(params[:id])
    respond_to do |format|
      format.html
    end
  end
  def update_inbound
    @manifest_sku = ManifestSku.find(params[:id])
    respond_to do |format|
      format.html
    end
  end

  def create_inventory
    @manifest = ManifestService.new(@manifest, current_user).create_manifest_inventory
    if @manifest
      redirect_to [current_user.role.to_sym, @manifest], success: "Inventory is being generated."
    else
      render :new, status: :unprocessable_entity
    end
  end

  def attach_images
    if @manifest.images.attach(params[:images])
      redirect_to [current_user.role.to_sym, @manifest], success: "Images Uploaded successfully"
    else
      render :new, status: :unprocessable_entity
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_manifest
      @manifest = ManifestRepo.new(current_user).find(params[:id])
      @comment = @manifest.comments.build
    end

    # Only allow a list of trusted parameters through.
    def manifest_params
      params.require(:manifest).permit(:identifier, :status, :manifest_type, :carrier_id,
                                       :origin_id, :destination_id, :schedule_at,
                                       :merchant_id, images: [],
                                       comments_attributes: [:body],
                                       manifest_skus_attributes: [:sku_id, :packaging, :quantity, :expiry_date])
    end

  def comments_params
    params.require(:comments).permit(:body)
  end

  def filtering_params(params)
    params.slice(:status, :type, :warehouse, :merchant, :carrier, :city)
  end
end
