class Admin::HomeController < DashboardController
  def index
    @inventory = Inventory.last

  end
end
