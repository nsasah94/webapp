class Admin::ManifestSkusController < DashboardController
  before_action :set_manifest, only: %i[ create show edit update destroy update_quantity ]

  def create
    manifest_id = params[:manifest_sku][:manifest_id]
    @manifest = Manifest.find(manifest_id)

    @record = ManifestService.new(@manifest, current_user).add_sku(manifest_sku_params)
    if @record
      redirect_to [:add_sku, current_user.role.to_sym, @manifest], success: "SKU was added successfully."
    else
      redirect_to [:add_sku, current_user.role.to_sym, @manifest], error: "SKU was not added."
    end
  end

  def destroy
    @manifest = ManifestService.new(nil, current_user).remove_manifest_sku(params[:id])
    redirect_to [:add_sku, current_user.role.to_sym, @manifest],
                success: "SKU was removed successfully."
  end

  def update_record
    parameters = {
      id:               params[:id],
      inventory_params: params[:manifest_sku]
    }

    # puts parameters
    # return
    @manifest = ManifestService.new(@manifest, current_user).update_quantity(parameters)

    redirect_to [current_user.role.to_sym, @manifest]
  end

  def create_record
    parameters = {
      id:               params[:id],
      inventory_params: params[:manifest_sku]
    }

    @manifest = ManifestService.new(@manifest, current_user).create_sku_record(parameters)

    redirect_to [current_user.role.to_sym, @manifest]
  end

  def set_manifest
    manifest_id = params[:manifest_sku][:manifest_id]
    @manifest = Manifest.find(manifest_id)
  end

  def manifest_sku_params
    params.require(:manifest_sku).permit(:sku_id, :packaging,
                                         :quantity, :expiry_date,
                                         :palletized, :total_pallets, :total_sqm, :total_wrapping, :total_segregation, :total_wooden_pallets,
                                         :loose_container, :container_size_ft,
                                         :good, :damaged, :missing, inventory_params: [:expiry_date, :storage_type, :storage_quantity, :number_of_pallets])
  end

end
