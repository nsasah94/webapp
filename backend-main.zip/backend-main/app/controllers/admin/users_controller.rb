class Admin::UsersController < DashboardController
  before_action :set_user, only: %i[ show edit update destroy ]

  def index
    @users = UserRepo.new(current_user).all
  end

  def new
    @user = User.new
    @address = Address.new
    @address.latitude = 23.8859
    @address.longitude = 45.0792
  end

  def edit
  end

  def show
    @pagy_warehouses, @warehouses = pagy(@user.warehouses.distinct.all)
    @pagy_suppliers, @suppliers = pagy(@user.suppliers.distinct.all)
  end

  def associate_warehouse_modal
    @user = User.find(params[:id])
    respond_to do |format|
      format.js
    end
  end

  def associate_warehouse
    @user = User.find(params[:id])
    @warehouse = Warehouse.find(params[:warehouse][:id])
    @user = WarehouseService.new(@warehouse).attach_user(@user)
    if @user
      flash[:notice] = "#{@user.name} has been added to #{@warehouse.name}"
      redirect_to admin_user_path @user
    end
  end

  def unassociate_warehouse
    @user = User.find(params[:id])
    @warehouse = Warehouse.find(params[:warehouse_id])
    @user = WarehouseService.new(@warehouse).detach_user(@user)
    if @user
      flash[:notice] = "#{@user.name} has been removed from #{@warehouse.name}"
      redirect_to admin_user_path @user
    end
  end

  def associate_supplier_modal
    @user = User.find(params[:id])
    respond_to do |format|
      format.js
    end
  end

  def associate_supplier
    @user = User.find(params[:id])
    @supplier = User.find(params[:supplier][:id])
    @user = SupplierService.new(@supplier).attach_user(@user)
    if @user
      flash[:notice] = "#{@user.name} has been added to #{@supplier.name}"
      redirect_to admin_user_path @user
    end
  end

  def unassociate_supplier
    @user = User.find(params[:id])
    @supplier = User.find(params[:supplier_id])
    @user = SupplierService.new(@supplier).detach_user(@user)
    if @user
      flash[:notice] = "#{@user.name} has been removed from #{@supplier.name}"
      redirect_to admin_user_path @user
    end
  end

  def create
    password = SecureRandom.hex(4)
    @user = UserService.new(user_params.merge(password: password)).create

    respond_to do |format|
      if @user
        UserMailer.with(user: @user, password: password).welcome_email.deliver_now
        format.html { redirect_to [current_user.role.to_sym, @user, locale: I18n.locale], notice: "User was successfully created." }
        format.json { render :show, status: :created, location: @user }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    @user = UserService.new(user_params.merge(id: params[:id])).update

    respond_to do |format|
      if @user
        format.html { redirect_to [current_user.role.to_sym, @user], notice: "User was successfully updated." }
        format.json { render :show, status: :ok, location: @user }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  private

  def set_user
    @user = UserRepo.new(current_user).find(params[:id])
    @address = @user.addresses.first
  end

  def user_params
    params.require(:user).permit(:firstname, :lastname, :email, :password, :vat_no, :cr_no,
                                 :company, :role, :status, :avatar, :phone, :mobile,
                                 address_attributes: [:city_name, :country_name, :name, :city_id, :address_type, :latitude, :longitude])
  end
end
