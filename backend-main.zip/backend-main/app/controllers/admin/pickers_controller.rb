class Admin::PickersController < DashboardController
  before_action :set_outbound, only: %i[ show reserve_inventory release_inventory update_outbound reserve_record  ]


  def index
    # List of Available Picking Lists
  end

  def show
    # Show the Outbound Picking List
    if params[:by_sku].present?
      @boxes_requested_skus = @outbound.outbound_skus.where(packaging: 1)
      query = {sku_id: params[:by_sku], quantity: 1}
      @pallet_inventories = Inventory.includes(:sku, :outbound_inventories, layout_location: [:layout_level, :layout_aisle])
                                     .where.not(layout_location_id: nil)
                                     .where(query, deducted_boxes: 0, outbound_id: nil)
                                     .order(layout_location_id: :asc)

      @boxes_to_pallets = (@pallet_inventories.sum(:boxes_per_pallet) / @pallet_inventories.size).to_i + 25
      @boxes_inventories = Inventory.includes(:sku, :outbound_inventories, layout_location: [:layout_level, :layout_aisle])
                                    .where(query)
                                    .where.not(layout_location_id: nil)
                                    .where('deducted_boxes < boxes_per_pallet')
                                    # .where('boxes_per_pallet <= ?', @boxes_to_pallets)
                                    .order(layout_location_id: :asc)
      @available_inventories = @pallet_inventories += @boxes_inventories
    end
  end

  def reserve_inventory
    @inventory = Inventory.find(params[:inventory_id])
    selected_pallets = OutboundInventory.where(outbound_id: @outbound.id, inventory_id: @inventory.id, packaging: 0).size
    number_of_pallets = @outbound.outbound_skus.where(packaging: 0).size

    selected_boxes_qty = OutboundInventory.where(outbound_id: @outbound.id, outbound_sku_id: @outbound.outbound_skus.where(sku_id: @inventory.sku_id).first.id, packaging: 1).sum(:quantity)
    if !selected_boxes_qty.eql?(@outbound.outbound_skus.where(packaging: 1).sum(:quantity))
      remaining_qty = @outbound.outbound_skus.where(packaging: 1).sum(:quantity) - selected_boxes_qty
      @inventory.update(deducted_boxes: remaining_qty)
      OutboundInventory.create(outbound_id: @outbound.id,
                               inventory_id: @inventory.id,
                               outbound_sku_id: @outbound.outbound_skus
                                                         .where(sku_id: @inventory.sku_id).first.id, packaging: 1, quantity: remaining_qty)
    end

    if !selected_pallets.eql?(number_of_pallets)
      OutboundInventory.create(outbound_id: @outbound.id, inventory_id: @inventory.id, outbound_sku_id: @outbound.outbound_skus.where(sku_id: @inventory.sku_id).first.id, packaging: 0, quantity: 1)
    end

    Inventory.where('deducted_boxes = boxes_per_pallet').update_all(quantity: 0)

    # if @inventory.deducted_boxes > 0
    #   remaining_qty = @inventory.boxes_per_pallet - @inventory.deducted_boxes
    #   OutboundInventory.create(outbound_id: @outbound.id, inventory_id: @inventory.id, outbound_sku_id: @outbound.outbound_skus.where(sku_id: @inventory.sku_id).first.id, packaging: 1, quantity: remaining_qty)
    # else
    #   if !selected_pallets.eql?(number_of_pallets)
    #     OutboundInventory.create(outbound_id: @outbound.id, inventory_id: @inventory.id, outbound_sku_id: @outbound.outbound_skus.where(sku_id: @inventory.sku_id).first.id, packaging: 0, quantity: 1)
    #   end
    # end

    return redirect_to admin_picker_path(@outbound.id), notice: 'Inventory Reserved'

  end


  def select_inventory
    @inventory = Inventory.find(params[:inventory_id])
    respond_to do |format|
      format.js
    end
  end

  def reserve_record
    puts params
    @inventory = Inventory.find(params[:inventory][:inventory_id])
    if params[:inventory][:packaging].eql?('box')
      InventoryManager::DeductBoxes.call(outbound_id: @outbound.id,
                                                    inventory_id: @inventory.id,
                                                    quantity: params[:inventory][:quantity])

      return redirect_to admin_picker_path(@outbound.id), notice: "#{params[:inventory][:quantity]} Boxes Reserved"
    elsif params[:inventory][:packaging].eql?('pallet_wrap')
      InventoryManager::DeductInventory.call(outbound_id: @outbound.id,
                                                        inventory_id: @inventory.id)
      return redirect_to admin_picker_path(@outbound.id), notice: "Pallet was Reserved"
    else
      return redirect_to admin_picker_path(@outbound.id), notice: "Can not fulfill #{params[:inventory][:packaging]} as it was not requested."
    end

    # if params[:inventory][:packaging].eql?('box')
    #   @success = InventoryManager::DeductBoxes.call(outbound_id: @outbound.id,
    #                                                 inventory_id: @inventory.id,
    #                                                 quantity: params[:inventory][:quantity])
    #   if @success
    #     return redirect_to admin_picker_path(@outbound.id), notice: 'Inventory Reserved'
    #   end
    # end
  end

  def release_inventory
    @inventory = Inventory.find(params[:inventory_id])
    OutboundInventory.where(outbound_id: @outbound.id, inventory: @inventory.id).first.destroy

    return redirect_to admin_picker_path(@outbound.id), notice: 'Inventory Released'
  end

  def update_outbound
    @outbound.update(status: :processing)
    # @outbound.inventories.update_all(outbound_id: @outbound.id)

    return redirect_to admin_outbound_path(@outbound.id), notice: 'Outbound is now Processing'
  end

  private

  def set_outbound
    @outbound = Outbound.includes(:outbound_skus, :outbound_inventories).find(params[:id])
    @boxes_requested_skus = @outbound.outbound_skus.where(packaging: 1) # Outbound SKUs as Boxes

    query = {sku_id: @outbound.outbound_skus.pluck(:sku_id), quantity: 1}

    # Query Pallets Inventory that have 0 deducted boxes and is assigned a location.
    @pallet_inventories = Inventory.includes(:sku, :outbound_inventories, layout_location: [:layout_level, :layout_aisle])
                                   .where.not(layout_location_id: nil)
                                   .where(query, deducted_boxes: 0)
                                   .order(layout_location_id: :asc)

    @available_inventories = @pallet_inventories

    if @outbound.outbound_skus.where(packaging: 1).size > 0
      @boxes_to_pallets = (@pallet_inventories.sum(:boxes_per_pallet) / @pallet_inventories.size).to_i + 10
      @boxes_inventories = Inventory.includes(:sku, :outbound_inventories, layout_location: [:layout_level, :layout_aisle])
                                    .where.not(id: @pallet_inventories.pluck(:id))
                                    .where.not(layout_location_id: nil)
                                    .where('deducted_boxes < boxes_per_pallet')
                                    .where(query, deducted_boxes: 0)
                                    .where('boxes_per_pallet <= ?', @boxes_to_pallets)

      @available_inventories = @pallet_inventories += @boxes_inventories
    end


  end

end
