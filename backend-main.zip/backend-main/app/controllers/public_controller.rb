class PublicController < ApplicationController
  def index
    # render current_user.role
    redirect_to new_user_session_path
  end

  def health
    render plain: 'ok', status: 200
  end
end
