class OutboundSkusController < ApplicationController
  before_action :set_outbound_sku, only: %i[ show edit update destroy ]

  # GET /outbound_skus or /outbound_skus.json
  def index
    @outbound_skus = OutboundSku.all
  end

  # GET /outbound_skus/1 or /outbound_skus/1.json
  def show
  end

  # GET /outbound_skus/new
  def new
    @outbound_sku = OutboundSku.new
  end

  # GET /outbound_skus/1/edit
  def edit
  end

  # POST /outbound_skus or /outbound_skus.json
  def create
    @outbound_sku = OutboundSku.new(outbound_sku_params)

    respond_to do |format|
      if @outbound_sku.save
        format.html { redirect_to outbound_sku_url(@outbound_sku), notice: "Outbound sku was successfully created." }
        format.json { render :show, status: :created, location: @outbound_sku }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @outbound_sku.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /outbound_skus/1 or /outbound_skus/1.json
  def update
    respond_to do |format|
      if @outbound_sku.update(outbound_sku_params)
        format.html { redirect_to outbound_sku_url(@outbound_sku), notice: "Outbound sku was successfully updated." }
        format.json { render :show, status: :ok, location: @outbound_sku }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @outbound_sku.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /outbound_skus/1 or /outbound_skus/1.json
  def destroy
    @outbound_sku.destroy

    respond_to do |format|
      format.html { redirect_to outbound_skus_url, notice: "Outbound sku was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_outbound_sku
      @outbound_sku = OutboundSku.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def outbound_sku_params
      params.require(:outbound_sku).permit(:outbound_id, :sku_id, :quantity, :packaging)
    end
end
