class Outbound < ApplicationRecord
  after_initialize :set_defaults

  belongs_to :origin, class_name: 'Address', foreign_key: 'origin_id', optional: true
  belongs_to :destination, class_name: 'Address', foreign_key: 'destination_id', optional: true
  belongs_to :carrier, class_name: 'DeliveryMethod', foreign_key: 'carrier_id', optional: true
  belongs_to :user, optional: true
  belongs_to :prepared_by, class_name: 'User', foreign_key: 'prepared_by', optional: true

  has_many :comments, as: :commentable
  has_many :outbound_skus
  has_many :inventories
  has_many :outbound_inventories
  has_many_attached :images

  # has_many :inventories
  accepts_nested_attributes_for :outbound_skus

  enum status: {
    draft: 0,
    created: 1,
    processing: 3,
    ready_for_delivery: 4,
    in_transit: 5,
    completed: 6,
    cancelled: 7
  }

  scope :filter_by_status, -> (status) { where(status: status) }
  scope :filter_by_merchant, -> (merchant) { where(merchant_id: merchant) }
  scope :filter_by_carrier, -> (carrier) { where(carrier_id: carrier) }

  enum vehicle_type: {
    cargo_van: 0,
    economy_car: 1,
    dyianna: 2,
    winch: 3,
    supplier_van: 4
  }

  enum delivery_type: {
    freight: 0,
    first_stop: 1,
    additional_stop: 2,
    dyianna_with_laborers: 3,
    additional_items: 4,
    out_of_city: 5
  }

  def set_defaults
    if self.new_record?
      self.status = :draft
      self.identifier = rand(111111111..999999999)
    end
  end

  def confirmable?
    self.status.to_sym.eql?(:draft) && !self.outbound_skus.empty?
  end

  def editable?
    self.status.to_sym.eql?(:draft) || self.status.to_sym.eql?(:created)
  end

  def number_of_boxes
    self.outbound_skus&.where(outbound_skus: {packaging: 1}).sum(:quantity)
  end

  def number_of_pallets
    self.outbound_skus&.where(outbound_skus: {packaging: 0}).sum(:quantity)
  end

end
