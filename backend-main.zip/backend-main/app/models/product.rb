class Product < ApplicationRecord
  belongs_to :merchant

  after_initialize :set_defaults

  scope :for_user, -> (current_user) {
    if current_user.merchant?
      where(merchant_id: current_user.id)
    else
      all
    end
  }

  private

  def set_defaults
    unless self.persisted?
      self.identifier ||= rand(111111111..999999999)
    end
  end

end
