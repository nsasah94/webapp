class Manifest < ApplicationRecord
  include Filterable

  belongs_to :merchant
  belongs_to :carrier, class_name: 'DeliveryMethod', foreign_key: 'carrier_id'
  has_many :manifest_skus, inverse_of: :manifest, dependent: :destroy
  has_one :origin, class_name: 'Address', primary_key: :origin_id, foreign_key: :id
  has_one :destination, class_name: 'Address', primary_key: :destination_id, foreign_key: :id
  has_many :inventories, through: :manifest_skus

  has_many :comments, as: :commentable
  accepts_nested_attributes_for :comments

  after_initialize :set_defaults

  has_many_attached :images

  validates_with ManifestValidator

  enum manifest_type: {
    inbound: 0,
    outbound: 1
  }

  enum status: {
    draft: 0,
    created: 1,
    in_transit: 2,
    received: 3,
    quality_control: 4,
    on_hold: 5,
    put_away: 6,
    complete: 7,
    cancelled: 8
  }

  scope :created, -> { where(status: :created) }
  scope :filter_by_status, -> (status) { where(status: status) }
  scope :filter_by_type, -> (type) { where(manifest_type: type) }
  scope :filter_by_warehouse, -> (warehouse) { where(destination_id: warehouse) }
  scope :filter_by_merchant, -> (merchant) { where(merchant_id: merchant) }
  scope :filter_by_carrier, -> (carrier) { where(carrier_id: carrier) }

  def confirmable?
    self.status.to_sym.eql?(:draft) && !self.manifest_skus.empty?
  end

  def editable?
    self.status.to_sym.eql?(:draft) || self.status.to_sym.eql?(:created) || self.status.to_sym.eql?(:quality_control)
  end

  def set_defaults
    if self.new_record?
      self.status = :draft
      self.manifest_type = :inbound
      self.identifier = rand(111111111..999999999)
    end
  end

end
