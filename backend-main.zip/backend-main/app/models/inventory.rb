class Inventory < ApplicationRecord
  include StorageType

  belongs_to :manifest_sku
  belongs_to :layout_location, optional: true

  belongs_to :sku, optional: true
  belongs_to :merchant, optional: true
  belongs_to :manifest, optional: true
  belongs_to :outbound, optional: true
  belongs_to :outbound_sku, optional: true
  has_many :outbound_inventories
  has_one :warehouse_layout, through: :layout_location
  has_one :warehouse, through: :warehouse_layout

  after_initialize :set_defaults

  def set_defaults
    if self.new_record?
      self.identifier = rand(111111111..999999999)
    end
  end

  def remaining_boxes
    self.boxes_per_pallet - self.deducted_boxes
  end

  def selected_storage_type
    case self.manifest_sku&.packaging
    when 0
      self.storage_type = 1
    when 1
      self.storage_type = 0
    end
  end

end
