class User < ApplicationRecord
  include ActiveModel::Validations

  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable, :timeoutable

  after_initialize :set_defaults

  has_one_attached :avatar

  validates_with ImageValidator
  validates_with UserValidator

  has_many :comments, :dependent => :destroy

  has_many :addresses, as: :addressable, :dependent => :destroy
  # Users Warehouses Association
  has_many :user_warehouses, :dependent => :destroy
  has_many :warehouses, through: :user_warehouses
  # End of Warehouses Association

  has_many :user_suppliers, :dependent => :destroy
  has_many :suppliers, through: :user_suppliers

  has_many :skus, foreign_key: :merchant_id

  has_many :sku_groups_users #, as: :items_groups
  has_many :sku_groups, through: :sku_groups_users

  has_many :user_employees
  has_many :employees, -> { where(role: :employee) }, through: :user_employees
  has_one :employer, class_name: 'UserEmployee', foreign_key: 'employee_id'

  enum role: {
    admin: 0,
    partner: 1,
    merchant: 2,
    employee: 3,
    driver: 4,
    supplier: 5,
    operator: 6
  }

  enum status: {
    active: 0,
    inactive: 1
  }

  scope :search_query, -> (query) { where('firstname ILIKE ? OR lastname ILIKE ? OR company ILIKE ?', "%#{query}%", "%#{query}%", "%#{query}%") }
  scope :partners, -> { where(role: :partner) }
  scope :merchants, -> { where(role: :merchant) }

  def name
    "#{firstname} #{lastname}"
  end

  def has_role?(role)
    self.role.to_sym.eql?(role)
  end

  def set_defaults
    unless self.persisted?
      self.role ||= :merchant
      self.status ||= :active
    end
  end

  def skus
    SkuGroupService.new(self).skus
  end

  private

  def send_devise_notification(notification, *args)
    devise_mailer.send(notification, self, *args).deliver_later
  end

end
