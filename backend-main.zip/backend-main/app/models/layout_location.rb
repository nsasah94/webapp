class LayoutLocation < ApplicationRecord
  include StorageType

  belongs_to :warehouse_layout
  belongs_to :layout_aisle
  belongs_to :layout_level
  belongs_to :layout_bay, optional: true

  delegate :layout_bay, to: :LayoutLevel

  has_many :inventories

  scope :empty_locations, -> { includes(:inventories).where(inventories: { sku_id: nil }) }
  scope :occupied_locations, -> { includes(:inventories).where.not(inventories: { sku_id: nil }) }
  scope :filter_by_type, -> (type) { includes(:warehouse_layout).where(warehouse_layout: {storage_type: type}) }
  scope :filter_by_warehouse, -> (warehouse) { includes(:warehouse_layout).where(warehouse_layout: { warehouse_id: warehouse }) }
  scope :filter_by_pickable, -> (pickable) { includes(:warehouse_layout).where(is_pickable: pickable) }
  scope :filter_by_storage_unit, -> (unit) { includes(:warehouse_layout).where(storage_unit: unit) }

  def full_name
    "#{self.layout_level.layout_bay.name}-#{self.layout_level.name}-#{self.name}"
  end

  def full_name_and_zone
    "#{self.warehouse_layout&.storage_type&.to_s&.titleize} | #{self.layout_level.layout_bay.name}-#{self.layout_level.name}-#{self.name}"
  end

end
