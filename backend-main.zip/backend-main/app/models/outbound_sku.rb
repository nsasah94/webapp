class OutboundSku < ApplicationRecord
  belongs_to :outbound
  belongs_to :sku
  # belongs_to :inventory, optional: true
end
