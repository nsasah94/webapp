class UserWarehouse < ApplicationRecord
  belongs_to :user
  belongs_to :warehouse

  # validates :role, inclusion: { in: [:partner, :merchant]}

  scope :manager_scope, -> { where(role: 1) }
  scope :merchant_scope, -> { where(role: 2) }

end
