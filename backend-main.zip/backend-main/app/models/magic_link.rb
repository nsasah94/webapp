class MagicLink < ApplicationRecord
  belongs_to :user
  after_create :send_mail

  def self.generate(email)
    user = User.find_by(email: email)
    return nil if !user

    create(user: user, expires_at: DateTime.now + 20.minutes, token: generate_token)
  end

  def self.generate_token
    Devise.friendly_token(48)
  end

  private
  def send_mail
    begin
      id = self.id
      MagicLinkJob.perform_async(id)
    rescue => e
      raise Exception.new e.message
    end
  end
end
