class WarehouseLayout < ApplicationRecord
  include StorageType

  belongs_to  :warehouse, dependent: :destroy
  has_many    :layout_aisles, -> {includes :layout_bays}, dependent: :destroy
  has_many    :layout_bays,   -> {includes :layout_levels}, through: :layout_aisles
  has_many    :layout_levels, -> {includes :layout_locations }, through: :layout_bays
  has_many    :layout_locations, through: :layout_levels
  has_many    :inventories, through: :layout_locations

  scope :filter_by_name, -> (name) { where(name: name) }
  scope :filter_by_warehouse, -> (warehouse) { where(warehouse_id: warehouse) }
  scope :filter_by_merchant, -> (merchant) { where(name: name) }
end
