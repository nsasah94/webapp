class DeliveryMethod < ApplicationRecord

  enum manifest_type: {
    inbound: 0,
    outbound: 1
  }

end
