class UserEmployee < ApplicationRecord
  belongs_to :user #, class_name: 'User', foreign_key: 'user_id'
  belongs_to :employee, class_name: 'User', foreign_key: 'employee_id'
end
