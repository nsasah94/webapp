class SkuSkuGroup < ApplicationRecord
  belongs_to :sku
  belongs_to :sku_group
end
