module StorageType
  extend ActiveSupport::Concern

  included do
    enum storage_type: {
      dry: 0, # Dry above 24 Degrees
      air_conditioned: 1, # Cool ambient 10 to 24 degrees
      refrigerated: 2, # Cold between 3 to 10 Degrees
      frozen: 3, # Below 0
    }

    enum storage_unit: {
      pallet: 0,
      shelf: 1,
      space: 2,
      bin: 3
    }

    enum packaging: {
      pallet_wrap: 0,
      box: 1,
      crate: 2,
      bale: 3,
      item: 4,
    }

    enum condition: {
      good: 0,
      bad: 1,
      missing: 2
    }

  end
end
