class LayoutBay < ApplicationRecord
  belongs_to  :warehouse_layout, dependent: :destroy
  belongs_to  :layout_aisle,     dependent: :destroy
  has_many    :layout_levels, -> {includes :layout_locations},    dependent: :destroy
  has_many    :layout_locations, through: :layout_levels
end
