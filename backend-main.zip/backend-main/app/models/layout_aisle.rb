class LayoutAisle < ApplicationRecord
  belongs_to :warehouse_layout, dependent: :destroy
  has_many :layout_bays, -> {includes :layout_levels, :layout_locations}, dependent: :destroy
  has_many :layout_locations, through: :layout_bays
end
