class Address < ApplicationRecord
  belongs_to :addressable, :polymorphic => true
  belongs_to :manifest, optional: true
  belongs_to :city

  attr_accessor :city_name, :country_name, :user_id

  enum address_type: {
    is_warehouse: 0,
    is_store: 1,
    is_private: 2,
    is_partner: 3,
    is_generic: 4,
  }

  def name
    "#{self.city&.name} - #{self.addressable&.name} #{super}"  || self[:name]
    # "#{self.addressable_type&.eql?('Warehouse') ? 'Warehouse' : (self.addressable.role&.eql?('merchant') ? 'Merchant' : 'Supplier')} - #{self.city&.name} - #{self.addressable&.name} #{super}"  || self[:name]
  end

  # getter
  def city_name
    @city_name
  end

  # setter
  def city_name=(val)
    @city_name = val
  end

  # getter
  def country_name
    @country_name
  end

  # setter
  def country_name=(val)
    @country_name = val
  end

end
