class LayoutLevel < ApplicationRecord
  belongs_to :warehouse_layout, dependent: :destroy
  belongs_to :layout_aisle,     dependent: :destroy
  belongs_to :layout_bay,     dependent: :destroy
  has_many :layout_locations

end
