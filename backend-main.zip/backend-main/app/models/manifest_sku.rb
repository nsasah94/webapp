class ManifestSku < ApplicationRecord
  include StorageType

  belongs_to :manifest
  belongs_to :sku
  has_many :inventories

  scope :sorted_skus, -> { includes(:sku).order('skus.sku_number desc') }

  def name
    "#{self.sku.sku_number} - #{self.sku.name}"
  end
end
