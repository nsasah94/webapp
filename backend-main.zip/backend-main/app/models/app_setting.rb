class AppSetting < ApplicationRecord
end
