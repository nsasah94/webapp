class Country < ApplicationRecord
  has_many :cities
end
