class Sku < ApplicationRecord
  include Colorscore
  include StorageType

  alias_attribute :sku_groups, :sku_sku_groups

  belongs_to :merchant, class_name: 'Merchant', foreign_key: 'merchant_id'
  has_many :manifest_skus
  has_many :outbound_skus
  has_many :inventories

  has_many :sku_sku_groups

  after_initialize :set_defaults

  has_one_attached :image

  validates :name, presence: true
  # validates :size, presence: true
  # validates :brand, presence: true
  # validates_uniqueness_of :upc, scope: :merchant_id
  validates_uniqueness_of :sku_number, scope: :merchant_id

  def stock_on_hand
    self.inventories&.sum(:quantity)
  end

  def major_color
    self.color
    # if self.image.attached?
    #   "##{Histogram.new(self.image.url).scores.first.second.hex}"
    # else
    #   self.color
    # end
  end

  def colors
    if self.image.attached?
      # Histogram.new(self.image.url).scores.map { |i| "##{i.second.hex}" }
    end
  end

  private

  def set_defaults
    unless self.persisted?
      self.system_sku ||= rand(111111111..999999999)
      self.merchant_sku ||= rand(111111111..999999999)
    end
  end


end
