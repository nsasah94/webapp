class City < ApplicationRecord
  belongs_to :country
end
