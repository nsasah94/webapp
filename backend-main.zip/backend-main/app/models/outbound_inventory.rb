class OutboundInventory < ApplicationRecord
  belongs_to :inventory
  belongs_to :outbound
  belongs_to :outbound_sku
  belongs_to :layout_location
end
