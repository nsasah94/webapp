class Partner < User

end
