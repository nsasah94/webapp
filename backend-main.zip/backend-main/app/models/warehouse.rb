class Warehouse < ApplicationRecord
  include Addressable

  has_many :warehouse_layouts
  has_many :layout_locations, through: :warehouse_layouts
  has_many :inventories, through: :layout_locations

  # Creates a Many to Many associations
  has_many :user_warehouses, :dependent => :destroy
  has_many :users, through: :user_warehouses

  has_many :users_managing, -> { manager_scope }, class_name: 'UserWarehouse'
  has_many :users_merchants, -> { merchant_scope }, class_name: 'UserWarehouse'

  has_many :managers, through: :users_managing, source: :user
  has_many :merchants, through: :users_merchants, source: :user
  # End of Many to Many association

  after_initialize :set_defaults

  accepts_nested_attributes_for :address

  enum warehouse_types: {
    partner: 0,
    in_house: 1
  }

  enum status: {
    active: 0,
    inactive: 1
  }

  validates :name, presence: true
  validates_uniqueness_of :name, message: 'already exists.'

  scope :filter_by_status, -> (status) { where(status: status) }
  scope :filter_by_type, -> (type) { where(warehouse_type: (type.eql?('partner') ? 0 : 1)) }
  scope :filter_by_city, -> (city) { includes(:addresses).where(addresses: {city_id: city}) }

  def set_defaults
    self.identifier = rand(111111111..999999999) if self.new_record?
  end

  def total_locations
    self.layout_locations.count
  end

end
