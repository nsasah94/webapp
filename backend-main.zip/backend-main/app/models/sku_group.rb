class SkuGroup < ApplicationRecord
  attr_accessor :sku_id

  belongs_to :user

  has_many :sku_groups_users
  has_many :sku_sku_groups

  has_many :users, through: :sku_groups_users
  has_many :skus, through: :sku_sku_groups

end
