class Merchant < User
  has_many :products
  has_many :skus
  has_many :manifests
  has_many :inventories, through: :skus

  def self.all
    User.where(role: :merchant).all
  end
end
