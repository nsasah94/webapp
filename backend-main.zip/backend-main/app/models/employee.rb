class Employee < User
  def self.all
    User.where(role: :employee).all
  end

  scope :active, -> { where(status: :active).order(:company) }
  scope :inactive, -> { where(status: :inactive).order(:company) }
end
