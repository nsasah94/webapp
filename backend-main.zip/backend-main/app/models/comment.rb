class Comment < ApplicationRecord
  belongs_to :commentable, polymorphic: true
  belongs_to :user, class_name: 'User', foreign_key: 'author_id', optional: true

  has_many_attached :images
end
