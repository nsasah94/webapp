class SkuGroupsUser < ApplicationRecord
  belongs_to :user
  belongs_to :sku_group
end
