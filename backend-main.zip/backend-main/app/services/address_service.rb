class AddressService
  attr_accessor :address

  def initialize(address)
    @address = address
  end

  def create(params, addressable)
    params.permit!
    @address = Address.new(params.merge!(addressable: addressable))
    @address.save
  end

  def update(params)
    params.permit!
    @address.update!(params)
  end

  private

  def address_params(params)
    params.permit(:name, :city_id, :latitude, :longitude)
  end
end
