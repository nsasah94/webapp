class EmployeeService
  attr_accessor :user

  def initialize(user)
    @user = user
  end

  def employer
    case user.role
    when 'employee'
      user.employer.user
    else
      nil
    end
  end

  def warehouses
    user.warehouses
  end

  def skus
    SkuGroupService.new(user).skus
  end

end
