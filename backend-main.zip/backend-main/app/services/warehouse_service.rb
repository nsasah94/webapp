class WarehouseService
  attr_accessor :warehouse

  def initialize(warehouse)
    @warehouse = warehouse
  end

  def raise_error(error_code: nil, error_status: nil, error_message: nil)
    raise GenericError.new(error_code: error_code, error_status: error_status, error_message: error_message)
  end

  def create(params)
      params.permit!
      ActiveRecord::Base.transaction do
          # Create on the fly, Country and City if they don't already exist
          @country = Country.find_or_create_by(name: params[:warehouse][:address_attributes][:country_name].strip)
          @city = City.find_or_create_by(name: params[:warehouse][:address_attributes][:city_name].strip, country_id: @country.id)
          params[:warehouse][:address_attributes][:city_id] = @city.id

          # Create the warehouse
          @warehouse = Warehouse.new(params[:warehouse])
          @warehouse.address = Address.new(params[:warehouse][:address_attributes])
          @warehouse.save
          # if @warehouse.save
          #   # @address_service = AddressService.new(Address.new)
          #   # @address_service.create(params[:warehouse][:address_attributes], @warehouse)
          # end
          @warehouse
      end

  end

  def update(params)
    params.permit!
    ActiveRecord::Base.transaction do
      # Create on the fly, Country and City if they don't already exist
      @country = Country.find_or_create_by(name: params[:warehouse][:address_attributes][:country_name].strip)
      @city = City.find_or_create_by(name: params[:warehouse][:address_attributes][:city_name].strip, country_id: @country.id)
      params[:warehouse][:address_attributes][:city_id] = @city.id

      # Create the warehouse
      @warehouse.update!(params[:warehouse])
      @address_service = AddressService.new(@warehouse.address)
      @address_service.update(params[:warehouse][:address_attributes])
      @warehouse
    end
  end

  # Assign a User to the Warehouse
  def attach_user(user)
    user_role = User.roles[user.role]
    UserWarehouse.find_or_create_by!(user: user, warehouse: @warehouse, role: user_role)
    user
  end

  # Unassign a User from the Warehouse
  def detach_user(user)
    user_role = User.roles[user.role]
    UserWarehouse.find_by(user: user, warehouse: @warehouse, role: user_role).destroy
    user
  end
end
