module InventoryManager
  class BoxQuantityCheck
    include Callable

    def initialize(params)
      puts params
      @sku = Sku.find(params[:sku_id])
      @quantity = params[:quantity]
    end

    def call
      quantity_check
    end

    private

    def quantity_check
      return Inventory.where(sku_id: @sku.id, quantity: 1, outbound_id: nil).sum(:boxes_per_pallet) >= @quantity
    end

  end
end

