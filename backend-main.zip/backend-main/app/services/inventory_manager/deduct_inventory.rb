module InventoryManager
  class DeductInventory
    include Callable

    def initialize(params)
      @outbound = Outbound.find(params[:outbound_id])
      @inventory = Inventory.find(params[:inventory_id])
    end

    def call
      deduct_inventory
    end

    private

    def deduct_inventory
      puts "DEDUCTING PALLET FROM INVENTORY"
      # Proceed if the Quantity of the Pallet is 1
      puts "INVENTORY HAVE 1 Pallet"
      # Number of Registered Pallets to be fulfilled for the Outbound
      remaining_pallets = OutboundInventory.where(outbound_id: @outbound.id,
                                                  outbound_sku_id: @outbound.outbound_skus.where(sku_id: @inventory.sku_id, packaging: 0).first.id,
                                                  packaging: 0,
                                                  quantity: 1).sum(:quantity)

      puts "Remaining Pallets"
      puts remaining_pallets
      # Number of Pallets Requested for the SKU in the Outbound
      requested_quantity = @outbound.outbound_skus.where(sku_id: @inventory.sku_id, packaging: 0).sum(:quantity).to_i

      puts "Requested Quantity"
      puts requested_quantity

      if remaining_pallets.to_i.eql?(requested_quantity)
        raise GenericError.new(error_code: 'INV-0001.4', error_status: 422, error_message: 'The Quantity of Pallets has been reserved, you can not reserve more than the requested quantity.')
      end

      ActiveRecord::Base.transaction do
        OutboundInventory.create!(outbound_id: @outbound.id,
                                  inventory_id: @inventory.id,
                                  outbound_sku_id: @outbound.outbound_skus.where(sku_id: @inventory.sku_id, packaging: 0).first.id,
                                  layout_location_id: @inventory.layout_location_id,
                                  packaging: 0,
                                  quantity: 1)
        puts "Updating Quantity in Transaction"
        @inventory.update!(quantity: 0.to_f, outbound_id: @outbound.id, layout_location_id: nil) # Reduce the Quantity by 1
      rescue ActiveRecord::Rollback => e
        raise GenericError.new(error_code: 'INV-0001.5', error_status: 422, error_message: e.full_message)
      end

      return true
      # # Update Available Pallets to Zero
      # @outbound.inventories.where(deducted_boxes: 0).update_all(quantity: 0)
      # # Sum Boxes Required
      # boxes_quantity = @outbound.outbound_skus.where(packaging: 1).sum(:quantity)
      # # Check if the Value of Inventories is a positive number
      # if (@outbound.inventories.where.not(deducted_boxes: 0).sum('boxes_per_pallet - deducted_boxes') - boxes_quantity).positive?
      #   # Check if the Inventories selected is equal to one.
      #   if @outbound.inventories.where.not(deducted_boxes: 0).size <= 1
      #     prev_deducted = @outbound.inventories.where.not(deducted_boxes: 0).first.deducted_boxes.to_i
      #     new_deducted = prev_deducted + boxes_quantity
      #     # Update the Deducted Amount
      #     @outbound.inventories.where.not(deducted_boxes: 0).first.update(deducted_boxes: new_deducted)
      #   end
      # end
    end
  end
end
