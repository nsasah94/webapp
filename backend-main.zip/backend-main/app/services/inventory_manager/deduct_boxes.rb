module InventoryManager
  class DeductBoxes
    include Callable

    def initialize(params)
      @outbound = Outbound.find(params[:outbound_id])
      @inventory = Inventory.find(params[:inventory_id])
      @quantity = params[:quantity]&.to_i
    end

    def call
      deduct_boxes
    end

    private

    def deduct_boxes
      if @inventory.remaining_boxes.to_i >= @quantity.to_i

        if (@quantity + reserved_quantities) > requested_quantities
          wrong_value = (@quantity + reserved_quantities)
          raise GenericError.new(error_code: 'INV-0001.2', error_status: 422, error_message: "#{wrong_value} is above the required quantities of #{requested_quantities}")
        end

        ActiveRecord::Base.transaction do
          # Create a record for deducting the boxes, and update the value in the inventory
          OutboundInventory.create!(outbound_id: @outbound.id,
                                   inventory_id: @inventory.id,
                                   layout_location_id: @inventory.layout_location_id,
                                   outbound_sku_id: @outbound.outbound_skus.where(sku_id: @inventory.sku_id, packaging: 1).first.id,
                                   packaging: 1,
                                   quantity: @quantity)
          updated_inventory_count = (@inventory.deducted_boxes.to_i + @quantity.to_i).to_i
          @inventory.update(deducted_boxes: updated_inventory_count)
          if updated_inventory_count.eql?(@inventory.boxes_per_pallet)
            # Make the Pallet unavailable
            @inventory.update(quantity: 0)
          end
        end
      else
        raise GenericError.new(error_code: 'INV-0001.1', error_status: 422, error_message: 'There is no enough quantity in this inventory location.')
      end
    end

    def reserved_quantities
      return OutboundInventory.includes(:inventory).where(outbound_id: @outbound.id, packaging: 1, inventories: {sku_id: @inventory.sku_id}).sum(:quantity).to_i
    end

    def requested_quantities
      return @outbound.outbound_skus.where(sku_id: @inventory.sku_id, packaging: 1).sum(:quantity).to_i
    end

  end
end
