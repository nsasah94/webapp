module InventoryManager
  class CreateInventory
    include Callable

    def initialize(params)
      @manifest_sku = ManifestSku.find(params[:manifest_sku_id])
    end

    def call
      create_records
    end

    private

    def create_records
      unless @manifest_sku.missing?
        @manifest_sku.storage_quantity.to_i.times do
          puts "Creating Good and Bad Inventory Records"
          Inventory.create(manifest_sku_id: @manifest_sku.id,
                           quantity: 1,
                           number_of_pallets: @manifest_sku.storage_quantity,
                           storage_unit: @manifest_sku.storage_unit,
                           expiry_date: @manifest_sku.expiry_date,
                           condition: @manifest_sku.condition,
                           storage_quantity:  @quantity_per_box,
                           boxes_per_pallet: @manifest_sku.quantity_per_package,
                           items_per_boxes: @manifest_sku.quantity_per_box,
                           merchant_id: @manifest_sku.manifest.merchant.id,
                           manifest_id: @manifest_sku.manifest.id,
                           sku_id: @manifest_sku.sku.id)

        end
        ManifestManager::ManifestStatusEditor.call(manifest_id: @manifest_sku.manifest_id, status: :complete)
      end

      return @manifest_sku.manifest
    end

  end
end
