module InventoryManager
  class AutoAssignLocation
    include Callable

    def initialize(params)
      # Find Merchant Aisles
      # Find Empty Locations
      # Assign Locations
      @manifest = Manifest.find(params[:manifest_id])
      @manifest_inventories = Inventory.where(manifest_id: @manifest.id, layout_location_id: nil)
      # Get Inventories that have Location IDs assigned
      assigned_locations = Inventory.where.not(layout_location_id: nil).pluck(:layout_location_id)
      @available_locations = LayoutLocation.where.not(id: assigned_locations)
    end

    def call
      assign_locations
    end

    private

    def assign_locations
      location_ids = @available_locations.order(layout_aisle_id: :asc).first(@manifest_inventories.size).pluck(:id)
      @manifest_inventories.each_with_index do |inventory, x|
        inventory.update(layout_location_id: location_ids[x])
      end
      @manifest.update(status: :complete)
    end

  end
end
