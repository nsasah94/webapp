module InventoryManager
  class PalletQuantityCheck
    include Callable

    def initialize(params)
      puts params
      @sku = Sku.find(params[:sku_id])
      @quantity = params[:quantity]
      @packaging = params[:packaging]
    end

    def call
      quantity_check
    end

    private

    def quantity_check
      return Inventory.where(sku_id: @sku.id, quantity: 1, outbound_id: nil).sum(:quantity) >= @quantity
    end

  end
end
