class UpdateEmptyPallet

  def initialize(inventory_id)
    # Deducted Boxed = Boxes per Pallet
    # Pallet is No Longer Available

  end

end
