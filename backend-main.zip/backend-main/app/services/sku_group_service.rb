class SkuGroupService
  attr_accessor :current_user, :sku_group, :sku

  def initialize(current_user=nil, sku_group=nil, sku=nil)
    @current_user = current_user unless current_user.nil?
    @sku_group = sku_group unless sku_group.nil?
    @sku = sku unless sku.nil?
  end

  def skus
    return nil unless current_user.present?
    case @current_user.role
    when 'admin'
      Sku.all
    when 'merchant'
      Sku.where(merchant_id: @current_user.id).all
    when 'partner'
      current_user.partners.last.warehouses.map { |w| w.merchants }.flatten.map {|m| m.skus }.flatten
    when 'employee'
      @skus = SkuGroup.joins(:sku_groups_users).where('sku_groups_users.user_id = ?', @current_user.id).map { |g| g.skus }.flatten
      if @skus.empty?
        @employer = EmployeeService.new(current_user).employer
        return Sku.where(merchant_id: @employer.id).all
      else
        @skus
      end
    else
      Sku.none
    end
  end

  def link_by_brand(group, brand)
    # SkuGroup.skus << Sku.where(brand: brand).all
  end

  def attach_group
    SkuGroupsUser.find_or_create_by!(user: current_user, sku_group: sku_group)
  end

  def detach_group
    SkuGroupsUser.find_by(user: current_user, sku_group: sku_group).destroy
  end

  def attach_sku
    SkuSkuGroup.find_or_create_by!(sku: sku, sku_group: sku_group)
  end

  def detach_sku
    SkuSkuGroup.find_by(sku: sku, sku_group: sku_group).destroy
  end

end
