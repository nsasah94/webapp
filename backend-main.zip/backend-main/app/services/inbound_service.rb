class InboundService
  attr_accessor :manifest

  # Handle Inbound by Package Type
  # Handle Damaged by Package Type

  def initialize(manifest)
    @manifest = manifest
  end

  # Create Record for each type
  # { quantity: 5, packaging: 1, status: :damaged, sku_id: 0 }

end
