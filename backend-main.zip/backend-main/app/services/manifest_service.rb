class ManifestService
  attr_accessor :manifest, :current_user

  def initialize(manifest, current_user)
    @manifest = manifest
    @current_user = current_user
  end

  def create_draft
    @manifest.status = :draft
    raise GenericError.new(error_code: 'MNF-0002.5', error_status: 422, error_message: 'Date must be 1 day in advance') unless @manifest.schedule_at >= (Time.now + 1.day)
    raise GenericError.new(error_code: 'MNF-0002.1', error_status: 422, error_message: 'Select origin address') unless @manifest.origin.present?
    raise GenericError.new(error_code: 'MNF-0002.2', error_status: 422, error_message: 'Select destination address') unless @manifest.destination.present?
    raise GenericError.new(error_code: 'MNF-0003', error_status: 422, error_message: 'Select delivery method') unless @manifest.carrier.present?
    if @manifest.carrier&.key.upcase.include?('supplier'.upcase)
      if !@manifest.origin&.addressable_type&.eql?('User')
        raise GenericError.new(error_code: 'MNF-0004', error_status: 422, error_message: 'Origin must be a Supplier Address') unless @manifest.origin&.addressable_type&.eql?('is_warehouse')
      elsif !@manifest.origin&.addressable&.role&.eql?('supplier')
          raise GenericError.new(error_code: 'MNF-0004', error_status: 422, error_message: 'Origin must be a Supplier Address')
      end
    end

    if @manifest.save
      return @manifest
    else
      raise GenericError.new(error_code: 'MNF-0001', error_status: 422, error_message: @manifest.errors.full_messages)
    end

  end

  def cancel
    self.change_status(status: :cancelled)
  end

  def add_sku(parameters = {})
    @manifest.manifest_skus.find_or_create_by(sku_id: parameters[:sku_id],
                                             packaging: parameters[:packaging]).update(parameters)
  end

  def remove_manifest_sku(id)
    @manifest_sku = ManifestSku.find(id)
    @manifest = @manifest_sku.manifest
    @manifest_sku.destroy
    @manifest
  end

  def change_status(status: Manifest.statuses)
    @manifest.update(status: status)
    if status.eql?('complete')
      NotificationManager::StatusNotifier.call(type: :manifest, record_id: @manifest.id)
    end
    @manifest
  end

  def update_quantity(parameters = {})
    @manifest_sku = ManifestSku.find(parameters[:id])

    if @manifest_sku.inventories.sum(:quantity) == @manifest_sku.quantity
      return @manifest_sku.manifest
    end

    @updated = @manifest_sku.update(
      condition: Sku.conditions[parameters[:inventory_params][:condition]],
      storage_unit: Sku.storage_units[parameters[:inventory_params][:storage_unit]],
      packaging: Sku.packagings[parameters[:inventory_params][:packaging]],
      sku_id: @manifest_sku.sku_id,
      manifest_id: @manifest_sku.manifest_id,
      quantity: parameters[:inventory_params][:quantity],
      palletized: parameters[:inventory_params][:palletized],
      loose_container: parameters[:inventory_params][:loose_container],
      container_size_ft: parameters[:inventory_params][:container_size_ft],
      total_pallets: parameters[:inventory_params][:total_pallets],
      total_sqm: parameters[:inventory_params][:total_sqm],
      total_wrapping: parameters[:inventory_params][:total_wrapping],
      total_segregation: parameters[:inventory_params][:total_segregation],
      total_wooden_pallets: parameters[:inventory_params][:total_wooden_pallets],
      quantity_per_package: parameters[:inventory_params][:quantity_per_package],
      quantity_per_box: parameters[:inventory_params][:quantity_per_box],
      storage_quantity: parameters[:inventory_params][:storage_quantity],
      expiry_date: parameters[:inventory_params][:sku_expiry],
    )

    # if @updated
    #   InventoryService.new(@manifest_sku).create_inventory(parameters[:good_qty],
    #                                                        parameters[:inventory_params])
    # end

    @manifest_sku.manifest
  end

  def create_sku_record(parameters = {})
    @manifest_sku = ManifestSku.find(parameters[:id])


    puts parameters

    # return

    @created = ManifestSku.create(
      condition: Sku.conditions[parameters[:inventory_params][:condition]],
      storage_unit: Sku.storage_units[parameters[:inventory_params][:storage_unit]],
      packaging: Sku.packagings[parameters[:inventory_params][:packaging]],
      sku_id: @manifest_sku.sku_id,
      manifest_id: @manifest_sku.manifest_id,
      quantity: parameters[:inventory_params][:quantity],
      palletized: parameters[:inventory_params][:palletized],
      loose_container: parameters[:inventory_params][:loose_container],
      container_size_ft: parameters[:inventory_params][:container_size_ft],
      total_pallets: parameters[:inventory_params][:total_pallets],
      total_sqm: parameters[:inventory_params][:total_sqm],
      total_wrapping: parameters[:inventory_params][:total_wrapping],
      total_segregation: parameters[:inventory_params][:total_segregation],
      total_wooden_pallets: parameters[:inventory_params][:total_wooden_pallets],
      quantity_per_package: parameters[:inventory_params][:quantity_per_package],
      quantity_per_box: parameters[:inventory_params][:quantity_per_box],
      storage_quantity: parameters[:inventory_params][:storage_quantity],
      expiry_date: parameters[:inventory_params][:sku_expiry],
      )

    @manifest_sku.manifest
  end

  def create_manifest_inventory
    @manifest.manifest_skus.each do |manifest_sku|
      InventoryManager::CreateInventory.call(manifest_sku_id: manifest_sku.id)
      # InventoryService.new(manifest_sku).create_inventory(manifest_sku.storage_quantity, manifest_sku.expiry_date, manifest_sku.storage_unit, manifest_sku.quantity_per_box)
    end

    return @manifest
  end
end
