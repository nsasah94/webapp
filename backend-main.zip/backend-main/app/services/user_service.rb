class UserService
  attr_accessor :user, :address_params, :user_params

  def initialize(params)
    user_params = params.except(:address_attributes)
    address_params = params[:address_attributes]
    # puts user_params
    # puts address_params

    @country = Country.find_or_create_by(name: address_params[:country_name].strip)
    @city = City.find_or_create_by(name: address_params[:city_name].strip, country_id: @country.id)
    address_params[:city_id] = @city.id

    @user_params = user_params
    @address_params = address_params
  end

  def create
    ActiveRecord::Base.transaction do
      @user = User.new(@user_params)
      @user.addresses.new(@address_params)
      @user.save
      @user
    end
  end

  def update
    ActiveRecord::Base.transaction do
      @user = User.find(@user_params[:id])

      @user.addresses.update(@address_params)
      @user.save
      @user

      # @user.update(@user_params.except(:id))
      # @user.addresses << Address.new(address_params)
      # @user.save
      # @user
    end
  end


end
