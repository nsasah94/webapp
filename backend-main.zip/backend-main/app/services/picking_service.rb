class PickingService
  require 'barby'
  require 'barby/barcode/code_128'
  require 'barby/barcode/code_39'
  require 'barby/outputter/png_outputter'
  require 'barby/outputter/ascii_outputter'
  require 'tempfile'

  require 'prawn/measurement_extensions'
  require 'prawn/table'
  require 'prawn/qrcode'
  require 'prawn/qrcode/table'
  require 'prawn/qrcode/table/cell'

  attr_accessor :outbound, :pdf

  def initialize(outbound)
    @outbound = outbound

    @outbound = Outbound.includes(:outbound_skus, :inventories).find(@outbound.id)
    @pdf = Prawn::Document.new(page_size: 'A4', page_layout: :portrait, :margin => [10,10,10,10]) do |pdf|
      pdf.fill_color('FFFFFF')
      pdf.fill_rectangle [pdf.bounds.left, pdf.bounds.top], pdf.bounds.right, pdf.bounds.top
    end
  end

  def generate_label

    @pdf.table company_info, width: 570, position: :center, cell_style: { padding: 2, border_width: 0 } do |t|
      t.cells.border_width = 0
    end

    @pdf.table page_header, width: 570, position: :center, cell_style: { :overflow => :shrink_to_fit, padding: 2, border_width: 0, dry_run: true } do |t|
      t.cells.border_width = 0
    end

    @pdf.table pdf_table_layout, width: 570, position: :center, cell_style: { :overflow => :shrink_to_fit, padding: 2, border_width: 0, dry_run: true } do |t|
      t.cells.border_width = 0
    end

    @pdf.table table_footer, width: 570, position: :center, cell_style: { :overflow => :shrink_to_fit, padding: 2, border_width: 0, dry_run: true } do |t|
      t.cells.border_width = 0
    end

    return @pdf
  end


  # private

  def pdf_table_layout
    return table_items
  end

  def page_header
    body_text_size = 12
    @pdf.fill_color('000000')
    company_info
    @pdf.move_down 10
    [
      [{ content: "Outbound Request Slip", font_style: :bold}],
      [{ content: "Submitted on", font_style: :bold }, { content: "#{@outbound.created_at.strftime("%d/%m/%Y")}", font_style: :bold }],
      [{ content: "" }],
      [{ content: "" }],
      [{ content: "Order for", size: body_text_size }, { content: "Order #", size: body_text_size }, { content: "Delivery Date", size: body_text_size }],
      [{ content: "#{@outbound.user&.company}", font_style: :bold }, { content: "#{@outbound.identifier}", font_style: :bold }, { content: "#{@outbound.schedule_at.strftime("%d/%m/%Y")}", font_style: :bold }],
    ]
  end

  def company_info
    body_text_size = 10
    @pdf.fill_color('000000')
    [
      [ { content: "Sirdab", size: body_text_size }, {image: "#{Rails.root}/app/assets/images/Sirdab_Logo_Arabic_English-p-500.png", :image_height => 35, :image_width => 100, :position  => :center, vposition: :top, scale: 0.2}],
      [ { content: "4867 Al Wadi St. Wadi Laban Dist.", size: body_text_size }],
      [ { content: "Riyadh 12935", size: body_text_size }],
      [ { content: "050 619 3344", size: body_text_size }],
      [ { content: "" } ],
      [ { content: "" } ]
    ]
  end

  def table_header
    @pdf.move_down 20
    header_text_size = 11
    header_font_weight = :normal
    body_text_size = 11
    @pdf.fill_color('000000')
    return [
      {content: "Item Reqeusted", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
      {content: "QTY Reserved", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
      {content: "Packaging", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
      {content: "Location", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
      {content: "QTY Prepared", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
    ]
  end

  def table_items
    header_text_size = 12
    font_weight = :normal
    body_text_size = 12
    @pdf.fill_color('000000')
    picking_list = [table_header]
    OutboundInventory.where(outbound_id: @outbound.id).order(inventory_id: :asc).each do |o_sku|
      picking_list << [
        {content: "#{o_sku.outbound_sku&.sku&.name}", size: body_text_size, align: :left, font_style: :bold, valign: :center},
        {content: "#{o_sku.quantity.to_i}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
        {content: "#{Sku.packagings&.key(o_sku.packaging)&.to_s&.titleize}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
        {content: "#{o_sku.layout_location&.full_name}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
        {content: "", size: body_text_size, align: :center, font_style: :bold, valign: :center},
      ]
    end
    return picking_list
  end

  def table_footer
    @pdf.move_down 20
    header_text_size = 11
    header_font_weight = :normal
    body_text_size = 11
    @pdf.fill_color('000000')
    [
      [
        {content: "Prepared By", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
        {content: " ", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
        {content: "", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
        {content: "Total QTY Prepared", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
        {content: "", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
      ]
    ]
  end

end
