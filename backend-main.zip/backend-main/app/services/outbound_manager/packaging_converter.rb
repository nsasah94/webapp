module OutboundManager
  class PackagingConverter
    include Callable

    def initialize(params)
      @outbound     = Outbound.find(params[:outbound_id])
      @inventory    = Inventory.where(sku_id: params[:sku_id], quantity: 1)
      @outbound_sku = OutboundSku.find(params[:outbound_sku_id]) unless params[:outbound_sku_id].nil?
      @packaging    = params[:packaging]
      @quantity     = params[:quantity]
    end

    # Check the Quantity Selected
    # Compare if it matches the number of Boxes in a Pallet
    # Convert to a Pallet
    # Create or Update the Record in the Outbound Manifest to a Pallet Type
    # If remaining boxes, create a boxes record.

    def call
      convert_packaging
    end


    private

    def convert_packaging
      case @packaging
      when :pallet_wrap
        puts 'Pallet'
      when :box
        puts 'Box'
        # Check if the Inventory containes Less or equal than the quantity requested
        puts @inventory.last.storage_quantity.to_i
        puts @quantity

        if @inventory.last.storage_quantity.to_i <= @quantity
          puts @inventory.first.storage_quantity.to_i
          puts @quantity
        end

      end
    end

  end
end
