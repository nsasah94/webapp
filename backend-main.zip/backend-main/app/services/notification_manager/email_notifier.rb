module NotificationManager
  class EmailNotifier
    include Callable

    def initialize(params)
      if params[:type].eql?(:manifest)
        @record = Manifest.includes(:origin, :merchant, :carrier, :manifest_skus).find(params[:record_id])
      elsif params[:type].eql?(:outbound)
        @record = Outbound.find(params[:record_id])
      end
    end

    def call
      notify_user
    end

    private

    def notify_user
      if @record.is_a?(Manifest)
        ManifestCreatedMailer.with(user: @record.merchant, record: @record).notify_user.deliver_now
      else
        OutboundCreatedMailer.with(user: @record.user, record: @record).notify_user.deliver_now
      end
    end

  end
end
