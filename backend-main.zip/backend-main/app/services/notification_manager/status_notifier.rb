module NotificationManager
  class StatusNotifier
    include Callable

    def initialize(params)
      if params[:type].eql?(:manifest)
        @type = 'Inbound'
        @record = Manifest.includes(:origin, :merchant, :carrier, :manifest_skus).find(params[:record_id])
      elsif params[:type].eql?(:outbound)
        @type = 'Outbound'
        @record = Outbound.find(params[:record_id])
      end
    end

    def call
      notify
    end

    private

    def notify
      user = @record.is_a?(Manifest) ? @record.merchant : @record.user
      ManifestStatusMailer.with(type: @type, user: user, record: @record).notify_user.deliver_now
    end

  end
end
