module NotificationManager
  class SlackNotifier
    include Callable

    def initialize(params)
      @record = nil
      puts params[:type]
      if params[:type].eql?(:manifest)
        @record = Manifest.includes(:origin, :merchant, :carrier, :manifest_skus).find(params[:manifest_id])
      elsif params[:type].eql?(:outbound)
        @record = Outbound.find(params[:outbound_id])
      end
    end

    def call
      trigger_notification
    end

    private

    def trigger_notification
      object = {
        "blocks": [
          {
            "type": "divider"
          }
        ],
        "attachments": [
          {
            "color": "#FFCC00",
            "author_name": @record.is_a?(Manifest) ? "Manifest Created" : "Outbound Created",
            "author_icon": "https://img.freepik.com/free-vector/megaphone-travel-icon-illustration_32991-1026.jpg",
            "title": @record.is_a?(Manifest) ? "Manifest #{@record.identifier}" : "Outbound #{@record.identifier}",
            "title_link": @record.is_a?(Manifest) ? "https://v2.sirdab.co/admin/manifests/#{@record.id}" : "https://v2.sirdab.co/admin/outbounds/#{@record.id}",
            "fields": [
              {
                "title": "Creation Date",
                "value": "#{@record.created_at.in_time_zone('Riyadh').strftime("%d/%m/%Y")}",
                "short": true
              },
              {
                "title": "Manifest ID",
                "value": "#{@record.identifier}",
                "short": true
              },
              {
                "title": "Merchant",
                "value": @record.is_a?(Manifest) ? "#{@record.merchant&.company}" : "#{@record.user&.company}",
                "short": true
              },
              {
                "title": "Carrier",
                "value": "#{@record.carrier&.name}",
                "short": true
              },
              {
                "title": "Number of Pallets",
                "value": @record.is_a?(Manifest) ? "#{@record.manifest_skus&.where(packaging: 0).sum(:quantity)}" : "#{@record.outbound_skus&.where(packaging: 0).sum(:quantity)}",
                "short": true
              },
              {
                "title": "Number of Boxes",
                "value": @record.is_a?(Manifest) ? "#{@record.manifest_skus&.where(packaging: 1).sum(:quantity)}" : "#{@record.outbound_skus&.where(packaging: 1).sum(:quantity)}",
                "short": true
              },
              {
                "title": "Scheduled On",
                "value": "#{@record.schedule_at.in_time_zone('Riyadh').strftime("%d/%m/%Y")}",
                "short": true
              }
            ],
            "thumb_url": "https://img.freepik.com/free-vector/megaphone-travel-icon-illustration_32991-1026.jpg",
            "footer": "#{ENV['APP_NAME']} Portal",
            "footer_icon": "https://img.freepik.com/free-vector/megaphone-travel-icon-illustration_32991-1026.jpg",
            "ts": Time.now.to_i
          }
        ]
      }

      @channel_url = @record.is_a?(Manifest) ? 'https://hooks.slack.com/services/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' : "https://hooks.slack.com/services/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"

      @result = HTTParty.post(@channel_url.to_str,
                              :body => object.to_json,
                              :headers => { 'Content-Type' => 'application/json' } )
    end

  end
end
