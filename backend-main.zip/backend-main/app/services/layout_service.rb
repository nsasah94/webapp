class LayoutService
  attr_accessor :current_user, :warehouse, :layout

  def initialize(current_user, warehouse, layout)
    @current_user = current_user
    @warehouse = warehouse
    @layout = layout
  end

  def generate_aisles
    create_aisles
  end

  def purge_all
    LayoutLocation.where(warehouse_layout_id: @layout.id).delete_all
    LayoutLevel.where(warehouse_layout_id: @layout.id).delete_all
    LayoutBay.where(warehouse_layout_id: @layout.id).delete_all
    LayoutAisle.where(warehouse_layout_id: @layout.id).delete_all
  end

  private

  def create_aisles
    aisle_names = [*('A'..'ZZ')].first(@layout.aisles)
    @layouts = []
    @layout.aisles.times do |index|
      identifier = rand(111111111..999999999)
      @layouts << { warehouse_layout_id: @layout.id,
                    identifier: identifier,
                    name: "#{aisle_names[index]}",
                    bays: @layout.bays,
                    levels: @layout.levels,
                    locations: @layout.locations }
    end
    raise "This layout is already generated" unless @layout.layout_aisles.empty?
    LayoutAisle.upsert_all(@layouts)

    create_bays
  end

  def create_bays
    @bays = []
    WarehouseLayout.includes(:layout_aisles).find(@layout.id).layout_aisles.each do |aisle|
      aisle.bays.times do |index|
        bay_identifier = rand(111111111..999999999)
        @bays << {warehouse_layout_id: @layout.id,
                  identifier: bay_identifier,
                  layout_aisle_id: aisle.id,
                  name: "#{aisle.name}-#{index+1}",
                  levels: @layout.levels,
                  locations: @layout.locations}
      end
    end

    LayoutBay.upsert_all(@bays)

    create_levels
  end

  def create_levels
    @levels = []
    WarehouseLayout.includes(:layout_bays, :layout_levels).find(@layout.id).layout_bays.each do |bay|

      @layout.levels.times do |index|
        level_name = [*('A'..'ZZ')][index]
        level_identifier = rand(111111111..999999999)
        @levels << {
          identifier: level_identifier,
          warehouse_layout_id: @layout.id,
          layout_aisle_id: bay.layout_aisle.id,
          layout_bay_id: bay.id,
          name: "#{level_name}",
          locations: @layout.locations
        }
      end

    end
    LayoutLevel.upsert_all(@levels)

    create_locations
  end

  def create_locations
    @locations = []

    WarehouseLayout.includes(:layout_bays, :layout_levels).find(@layout.id).layout_levels.each do |level|
      # Iterate x times for locations in the level.
      @layout.locations.times do |index|
        location__identifier = rand(111111111..999999999)
        # Append Locations to the array.
        @locations << {
          identifier: location__identifier,
          warehouse_layout_id: @layout.id,
          layout_aisle_id: level.layout_bay.layout_aisle.id,
          layout_level_id: level.id,
          full_name: "#{level.layout_bay.layout_aisle.name}-#{level.layout_bay.name}-#{level.name}-#{index+1}",
          name: "#{index+1}",
          storage_unit: @layout.storage_unit
        }
      end
    end

    LayoutLocation.upsert_all(@locations)
  end

end
