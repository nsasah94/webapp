class SupplierService

  def initialize(supplier)
    @supplier = supplier
  end

  def attach_user(user)
    UserSupplier.find_or_create_by!(user: user, supplier: @supplier)
    user
  end

  # Unassign a User from the Warehouse
  def detach_user(user)
    UserSupplier.find_by(user: user, supplier: @supplier).destroy
    user
  end

end
