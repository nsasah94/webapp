class OutboundService
  attr_accessor :outbound, :current_user

  # Inventory Parameter must be sku and quantity
  def initialize(outbound = nil, current_user = nil)
    @outbound = outbound
    @current_user = current_user
  end

  def availability_check(sku_id, quantity, packaging)
    boxes_available = (Inventory.includes(:sku).where(quantity: 1, sku: {id: sku_id}).sum(:boxes_per_pallet) - Inventory.includes(:sku).where(quantity: 1, sku: {id: sku_id}).sum(:deducted_boxes)).to_i
    pallets_available = Inventory.includes(:sku).where(quantity: 1, sku: {id: sku_id}).sum(:quantity).to_i

    case packaging
    when '0'
      raise GenericError.new(error_code: 'STKx01732', error_status: 422, error_message: "There is only #{pallets_available} pallets in stock available.") unless pallets_available >= quantity.to_i
    when '1'
      raise GenericError.new(error_code: 'STKx01732', error_status: 422, error_message: "There is only #{boxes_available} boxes in stock available.") unless boxes_available >= quantity.to_i
    end
  end

  def create_manifest
    availability_check
  end

  def cancel
    self.change_status(status: :cancelled)
  end

  def change_status(status: Outbound.statuses)
    @outbound.update(status: status)
    @outbound
  end

  def update_inventory
    if @outbound.ready_for_delivery?
      # InventoryManager::DeductInventory.call(outbound_id: @outbound.id)
      # @outbound.outbound_skus&.each do |sku|
      #   # puts Inventory.includes(:sku)
      #   #               .where(sku: {id: sku.sku_id})
      #   #               .first(sku.quantity.to_i).size
      #
      #
      #   # Inventory.includes(:sku)
      #   #          .where(sku: {id: sku.sku_id}, quantity: 1)
      #   #          .first(sku.quantity.to_i).each do |inventory|
      #   #   inventory.update(quantity: 0, outbound_id: @outbound.id)
      #   # end
      #
      #   InventoryManager::DeductInventory.call(outbound_id: @outbound.id)
      # end
    end

  end


end
