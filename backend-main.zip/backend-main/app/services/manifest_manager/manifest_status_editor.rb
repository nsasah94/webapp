module ManifestManager
  class ManifestStatusEditor
    include Callable

    def initialize(params)
      @manifest = Manifest.find(params[:manifest_id])
      @status = params[:status]
    end

    def call
      change_status
    end

    def change_status
      @manifest.update(status: @status)
      @manifest
    end
  end
end
