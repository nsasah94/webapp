class InventoryService
  attr_accessor :manifest_sku, :quantity, :expiry_date, :storage_unit, :quantity_per_box
  def initialize(manifest_sku)
    @manifest_sku = manifest_sku
  end

  def create_inventory(quantity, expiry_date, storage_unit, quantity_per_box)
    puts "Creating Inventory record"
    # Validate Quantity
    @quantity = quantity
    @expiry_date = expiry_date
    @storage_unit = storage_unit
    @quantity_per_box = quantity_per_box

    # puts Sku.storage_units.key(storage_unit)

    case Sku.storage_units.key(storage_unit)
    when 'box'
      return
    else
      creation_steps
    end


    return @manifest_sku.manifest
  end

  def creation_steps
    # Send the Request to the Sidekiq Workers to perform
    InventoryManager::CreateInventoryJob.perform_async({
                                                       manifest_id: @manifest.id,
                                                       quantity: @quantity,
                                                       manifest_sku_id: @manifest_sku.id,
                                                       storage_unit: @storage_unit,
                                                       expiry_date: @expiry_date,
                                                       storage_quantity:  @quantity_per_box
                                                     })
  end
end
