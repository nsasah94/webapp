class SkuService
  attr_accessor :sku
  def initialize(sku)
    @sku = sku
  end

end
