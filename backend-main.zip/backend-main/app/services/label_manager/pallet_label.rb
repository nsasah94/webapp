module LabelManager
  class PalletLabel
    include Callable

    def initialize(params)
      @inventory = Inventory.find(params[:inventory_id])

      @pdf = Prawn::Document.new(page_size: 'A6', page_layout: :portrait, :margin => [10,10,10,10]) do |pdf|
        pdf.fill_color('FFFFFF')
        pdf.fill_rectangle [pdf.bounds.left, pdf.bounds.top], pdf.bounds.right, pdf.bounds.top
      end
    end

    def call
      execute
    end

    private

    def execute
      # barcode(@inventory.sku&.merchant_sku)
      # barcode(@inventory.sku&.system_sku)
      @pdf.move_down 20
      # SKU Generic Information
      @pdf.table pdf_table_layout, width: @pdf.bounds.width, position: :center, cell_style: { :overflow => :shrink_to_fit, padding: 5, border_width: 0 } do |t|
        t.cells.border_width = 1
      end

      @pdf.move_down 10

      # SKU Name and Expiry
      @pdf.table pdf_table_merchant_layout, width: @pdf.bounds.width, position: :center, cell_style: { :overflow => :shrink_to_fit, padding: 5, border_width: 0 } do |t|
        t.cells.border_width = 1
      end

      # @pdf.move_down 20
      #
      # # SKU Name and Expiry
      # @pdf.table pdf_table_merchant_sku, width: @pdf.bounds.width, position: :center, cell_style: { :overflow => :shrink_to_fit, padding: 1, border_width: 0 } do |t|
      #   t.cells.border_width = 0
      # end

      @pdf
    end

    def pdf_table_layout
      header_text_size = 11
      header_font_weight = :normal
      body_text_size = 44
      @pdf.fill_color('000000')
      [
        [
          {content: "Product Name", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF", colspan: 2},
        ],
        [
          {content: "#{@inventory.sku&.name}", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "FFFFFF", colspan: 2},
        ],
        [
          {content: "Inbound Date", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
          {content: "#{@inventory.manifest&.updated_at.in_time_zone('Riyadh').to_date}", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "FFFFFF"},
        ],
        [
          {content: "Merchant", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
          {content: "#{@inventory.sku&.merchant&.company}", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "FFFFFF"},
        ],
        [
          {content: "Merchant SKU", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
          {content: "#{@inventory.sku&.sku_number}", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "FFFFFF"},
        ],
        [
          {content: "Identifier", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
          {content: "#{@inventory.identifier}", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "FFFFFF"},
        ],
        [
          {content: "System SKU", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
          {content: "#{@inventory.sku&.system_sku}", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "FFFFFF"},
        ],
        [
          {content: "Location", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
          {content: "#{@inventory.layout_location&.full_name_and_zone}", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "FFFFFF"},
        ],
        [
          {content: "Warehouse", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
          {content: "#{@inventory.layout_location&.warehouse_layout&.warehouse&.name}", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "FFFFFF"},
        ]
      ]
    end

    def pdf_table_merchant_layout
      header_text_size = 11
      header_font_weight = :normal
      body_text_size = 44
      @pdf.fill_color('000000')
      [

        [
          {content: "Expiry", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
          {content: "#{@inventory.expiry_date.present? ? @inventory.expiry_date : 'No Expiry'}", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "FFFFFF"},
        ],
        [
          {content: "# Boxes", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "EFEFEF"},
          {content: "#{@inventory.boxes_per_pallet.to_i}", size: header_text_size, font_style: header_font_weight, align: :left, background_color: "FFFFFF"},
        ]
      ]
    end

    def pdf_table_merchant_sku
      header_text_size = 12
      header_font_weight = :normal
      body_text_size = 44
      @pdf.fill_color('000000')
      [
        [
          {image: "#{Rails.root}/tmp/#{@inventory.sku&.merchant_sku}.png", :image_height => 50, :image_width => 100, :position  => :center, vposition: :center},
          {image: "#{Rails.root}/tmp/#{@inventory.sku&.system_sku}.png", :image_height => 50, :image_width => 100, :position  => :center, vposition: :center}
        ],
        [
          {content: "#{@inventory.sku&.merchant_sku}", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "FFFFFF"},
          {content: "#{@inventory.sku&.system_sku}", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "FFFFFF"},
        ]
      ]
    end

    def barcode(name)
      barcode = Barby::Code128.new("#{name}")
      outputter = Barby::PngOutputter.new(barcode)
      File.open("#{Rails.root}/tmp/#{name}.png", 'wb'){|f| f.write outputter.to_png(margin: 0, height: 160, width: 800) }
    end

  end
end
