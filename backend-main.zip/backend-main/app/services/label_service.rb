class LabelService
  require 'barby'
  require 'barby/barcode/code_128'
  require 'barby/barcode/code_39'
  require 'barby/outputter/png_outputter'
  require 'barby/outputter/ascii_outputter'
  require 'tempfile'

  require 'prawn/measurement_extensions'
  require 'prawn/table'
  require 'prawn/qrcode'
  require 'prawn/qrcode/table'
  require 'prawn/qrcode/table/cell'

  attr_accessor :location

  def initialize(location = nil)
    @location = location

    @pdf = Prawn::Document.new(page_size: [400, 200], page_layout: :portrait, :margin => [10,10,10,10]) do |pdf|
      pdf.fill_color('FFFFFF')
      pdf.fill_rectangle [pdf.bounds.left, pdf.bounds.top], pdf.bounds.right, pdf.bounds.top
    end
    # location_barcode
  end

  def generate_label
    if !@location.nil?
      location_barcode(@location.identifier)
    end
    @pdf.table pdf_table_layout, width: 380, position: :center, cell_style: { :overflow => :shrink_to_fit, padding: 2, border_width: 0 } do |t|
      t.cells.border_width = 2
    end

    return @pdf
  end

  def pdf_table_layout
    header_text_size = 18
    header_font_weight = :normal
    body_text_size = 44
    @pdf.fill_color('000000')
    [
      [
        {content: "Aisle", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
        {content: "Bay", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
        {content: "Level", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
        {content: "Location", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
      ],
      [
        {content: "#{@location.layout_aisle&.name}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
        {content: "#{@location.layout_level&.layout_bay&.name}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
        {content: "#{@location.layout_level&.name}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
        {content: "#{@location.name}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
      ],
      [
        {content: "#{@location.full_name}", size: 70, font_style: :bold, align: :center, valign: :center, colspan: 3},
        {image: "#{Rails.root}/tmp/#{@location.identifier}.png", :image_height => 50, :image_width => 100, :position  => :center, vposition: :center}
      ]
    ]
  end

  def quick_locations(aisle, bays, shelves, locations)
    # aisle_names = [*('A'..'ZZ')].first(aisles.to_i)
    # aisles.to_i.times do |aisle_index|
    #   aisle_name = "#{aisle_names[aisle_index]}"
      bays.to_i.times do |bay_index|
        bay_name = "#{bay_index+1}"
        shelves.to_i.times do |level_index|
          level_name = "#{level_index+1}"
          locations.to_i.times do |location_index|
            location_name = "#{location_index+1}"
              @pdf.start_new_page if location_index > 0 # Check for the index of the page
              setup_label_size(aisle, bay_name, level_name, location_name)
          end
        end
      # end
    end

    return @pdf

  end

  def setup_label_size(aisle_name, bay_name, level_name, location_name)
    @pdf.table create_raw_labels(aisle_name, bay_name, level_name, location_name), width: 380, position: :center, cell_style: { :overflow => :shrink_to_fit, padding: 2, border_width: 0 } do |t|
      t.cells.border_width = 2
    end
  end

  def create_raw_labels(aisle_name, bay_name, shelf_name, location_name)
    location = "#{aisle_name}-#{bay_name}-#{shelf_name}-#{location_name}"
    location_barcode(location)
    header_text_size = 18
    header_font_weight = :normal
    body_text_size = 44
    # qrcode_content = location
    # qrcode = RQRCode::QRCode.new(qrcode_content, level: :h, size: 5)
    @pdf.fill_color('000000')
    [
      [
        {content: "Aisle", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
        {content: "Bay", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
        {content: "Shelf", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
        {content: "Location", size: header_text_size, font_style: header_font_weight, align: :center, background_color: "EFEFEF"},
      ],
      [
        {content: "#{aisle_name}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
        {content: "#{bay_name}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
        {content: "#{shelf_name}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
        {content: "#{location_name}", size: body_text_size, align: :center, font_style: :bold, valign: :center},
      ],
      [
        {content: "#{location}", size: 70, font_style: :bold, align: :center, valign: :center, colspan: 3},
        {image: "#{Rails.root}/tmp/#{location}.png", :image_height => 50, :image_width => 100, :position  => :center, vposition: :center}
      ]
    ]
  end

  def location_barcode(name)
    barcode = Barby::Code128.new("#{name}")
    outputter = Barby::PngOutputter.new(barcode)
    File.open("#{Rails.root}/tmp/#{name}.png", 'wb'){|f| f.write outputter.to_png(margin: 0, height: 160, width: 800) }
  end

end
