class Manifest::StateJob
  include Sidekiq::Job
  sidekiq_options queue: 'default'

  def perform(*args)
    # Do something
    puts args
  end
end
