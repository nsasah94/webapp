class MagicLinkJob
  include Sidekiq::Job
  include ExceptionNotifier

  def perform(*args)
    @magic_link = MagicLink.find(args).first
    MagicLinkMailer.sign_in_mail(@magic_link).deliver
  end
end
