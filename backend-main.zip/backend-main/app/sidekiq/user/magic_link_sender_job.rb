class User::MagicLinkSenderJob
  include Sidekiq::Job
  sidekiq_options queue: 'high'

  def perform(*args)
    user = User.new(args)
    puts user
  end
end
