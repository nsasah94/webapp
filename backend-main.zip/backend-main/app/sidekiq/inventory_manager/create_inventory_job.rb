class InventoryManager::CreateInventoryJob
  include Sidekiq::Job

  def perform(args)
    # Do something
    args = JSON.parse(args, object_class: OpenStruct).first
    puts args.manifest_id

    quantity = args.quantity.to_i
    storage_unit = args.storage_unit
    expiry_date = args.expiry_date
    storage_quantity = args.storage_quantity
    manifest_sku = ManifestSku.find(args.manifest_sku_id)
    manifest = Manifest.find(args.manifest_id)

    quantity.to_i.times do
      # Create an Inventory record for each pallet in the system
      puts "Creating the record"
      if manifest_sku.good? || manifest_sku.bad?
        Inventory.create(manifest_sku_id: manifest_sku.id, quantity: 1,
                         number_of_pallets: @quantity,
                         storage_unit: Inventory.storage_units.key(storage_unit),
                         expiry_date: expiry_date,
                         condition: manifest_sku.condition,
                         storage_quantity:  storage_quantity,
                         boxes_per_pallet: manifest_sku.quantity_per_package,
                         items_per_boxes: manifest_sku.quantity_per_box,
                         merchant_id: manifest_sku.manifest.merchant.id,
                         manifest_id: manifest.id,
                         sku_id: manifest_sku.sku.id)
      end
    end

  end
end
