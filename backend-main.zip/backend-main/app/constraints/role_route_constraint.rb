class RoleRouteConstraint
  def initialize(&block)
    @block = block || lambda { |user| true }
  end

  def matches?(request)
    user = current_user(request)
    user.present? && @block.call(user)
    puts "User", user.role.eql?('admin')
  end

  def current_user(request)
    User.find(request.session["warden.user.user.key"][0]).first
  end
end
