require 'sidekiq/web'

Rails.application.routes.draw do
  get 'comments/create'
  mount Sidekiq::Web => "/sidekiq" # mount Sidekiq::Web in your Rails app

  get 'health', to: 'public#health'

  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html
  devise_for :users

  get 'magic_links/new', as: :new_magic_link
  post 'magic_links/create', as: :magic_link
  get 'magic_links/validate', as: :email_link

  # Defines the root path route ("/")
  scope "(:locale)", locale: /#{I18n.available_locales.join("|")}/, defaults: {locale: :en} do
    root to: 'public#index'

    namespace :admin do
      root 'home#index'
      resources :app_settings
      resources :addresses
      resources :delivery_methods
      resources :users do
        member do
          get :associate_warehouse_modal
          post :associate_warehouse
          delete :unassociate_warehouse
          # Supplier Association
          get :associate_supplier_modal
          post :associate_supplier
          delete :unassociate_supplier
        end
      end
      resources :cities
      resources :countries
      resources :products
      resources :suppliers
      resources :skus
      resources :outbound_skus
      resources :sku_groups do
        member do
          # Link User to Group
          get :link_user_modal
          post :link_user
          post :unlink_user
          # Link SKU to Group
          get :link_sku_modal
          post :link_sku
          post :unlink_sku
        end
      end
      resources :incidents
      resources :manifest_skus do # Manifest SKUs
        member do
          post :save_sku
          post :update_quantity
          post :create_record
          post :update_record
        end
      end
      resources :pickers do
        member do
          get :reserve_inventory
          get :release_inventory
          get :update_outbound
          get :select_inventory
          post :reserve_record
        end
      end
      resources :outbounds do # Outbounds
        member do
          get :change_status
          get :confirm
          get :print_picker_list
          post :add_or_update_inventory
          post :update_inventory
          post :update_outbound
          post :attach_images
          post :remove_sku_from_outbound
          post :add_comment
          delete :remove_inventory
          delete :cancel_outbound
        end
      end
      resources :comments
      resources :manifests do # Manifests
        collection do
          get :search
        end
        member do
          get :create_inbound
          get :update_inbound
          get :create_inventory
          get :confirm
          get :add_sku
          get :change_status
          post :add_comment
          post :attach_images
          delete :cancel_manifest
        end
      end
      resources :put_away
      resources :warehouse_layouts
      resources :warehouses do # Warehouses
        member do
          get :add_merchants
          get :toggle_status
          post :add_merchants
        end
        collection do
          get :partners
          get :in_house
        end
      end
      resources :inventories do
        member do
          get :print_pallet_label
          get :histories
          post :assign_location
          delete :destroy_inventory, to: 'inventories#destroy'
        end
      end
      resources :layout_locations do
        member do
          post :update_location
        end
      end
      resources :stock_locations do
        member do
          get :assign_location, param: :inventory_id
          get :stock_location_label, param: :location_id
        end
        collection do
          get :new_generic_label
          post :generic_location_label
        end
      end
      resources :merchants
      resources :partners
      resources :employees
    end

    # Partners
    namespace :partner do
      root 'home#index'
    end

    # Merchants
    namespace :merchant do
      root 'home#index'
      resources :outbound_skus
      resources :addresses
      resources :warehouses
      resources :skus
      resources :inventories do
        member do
          get :histories
        end
      end
      resources :sku_groups do
        member do
          # Link User to Group
          get :link_user_modal
          post :link_user
          post :unlink_user
          # Link SKU to Group
          get :link_sku_modal
          post :link_sku
          post :unlink_sku
        end
      end
      resources :users
      resources :products
      resources :countries

      resources :outbounds do # Outbounds
        member do
          get :confirm
          post :add_or_update_inventory
          delete :remove_inventory
          post :update_inventory
          post :add_comment
          post :remove_sku_from_outbound
        end
      end

      resources :manifest_skus do
        member do
          post :save_sku
        end
      end
      resources :manifests do
        collection do
          get :search
        end
        member do
          get :confirm
          get :add_sku
          delete :cancel_manifest
        end
      end
    end

    # Merchant Employees Routes
    namespace :employee do
      root 'home#index'
      resources :manifests
      resources :outbounds
      resources :skus
      resources :warehouses
    end

  end

end
