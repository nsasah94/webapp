require_relative "boot"

require "rails/all"
require "prawn"
require 'prawn/qrcode'
require 'prawn-styled-text'

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module Backend
  class Application < Rails::Application
    # Initialize configuration defaults for originally generated Rails version.
    config.load_defaults 7.0

    # Configuration for the application, engines, and railties goes here.
    #
    # These settings can be overridden in specific environments using the files
    # in config/environments, which are processed later.
    #
    # config.time_zone = "Central Time (US & Canada)"
    # config.eager_load_paths << Rails.root.join("extras")

    config.action_mailer.smtp_settings = {
      user_name: ENV['AWS_SES_SMTP_USER'],
      password: ENV['AWS_SES_SMTP_PASSWORD'],
      address: ENV['AWS_SES_SMTP_ENDPOINT'],
      domain:  ENV['APP_DOMAIN'],
      port: 587,
      authentication: :login,
      enable_starttls_auto: true
    }

    config.hosts = [
      IPAddr.new("0.0.0.0/0"), # All IPv4 addresses.
      IPAddr.new("::/0"),      # All IPv6 addresses.
      "localhost",              # The localhost reserved domain.
      "devlb-1902624016.eu-central-1.elb.amazonaws.com",
      "sirdab.co",
      ".sirdab.co",
      ".amazonaws.com"
    ]

    Rails.application.config.hosts = nil

    # Rails.application.config.middleware.use ExceptionNotification::Rack,
    #                                         email: {
    #                                           email_prefix: "#{ENV['RAILS_ENV']} ",
    #                                           sender_address: %{"Exception" <noreply@sirdab.co>},
    #                                           exception_recipients: %w{mkaakati@sirdab.co},
    #                                           delivery_method: :smtp,
    #                                           smtp_settings: {
    #                                             user_name: ENV['AWS_SES_SMTP_USER'],
    #                                             password: ENV['AWS_SES_SMTP_PASSWORD'],
    #                                             address: ENV['AWS_SES_SMTP_ENDPOINT'],
    #                                             domain:  ENV['APP_DOMAIN'],
    #                                             port: 587,
    #                                             authentication: :login,
    #                                             enable_starttls_auto: true
    #                                           }
    #                                         }


  end
end
