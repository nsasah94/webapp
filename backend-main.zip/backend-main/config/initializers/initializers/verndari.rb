# Verndari.configure do |config|
#   config.host = "sirdab.co"
#   config.email = 'notifications@sirdab.co'
# end
