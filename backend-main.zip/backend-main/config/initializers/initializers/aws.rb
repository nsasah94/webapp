# Aws::Rails.add_action_mailer_delivery_method(
#   :ses,
#   credentials: {
#     "AccessKeyId": 'AKIAZLNZUFRESAMLWFOY',
#     "SecretAccessKey": '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'
#   },
#   region: 'eu-central-1'
# )
