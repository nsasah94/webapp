require "test_helper"

class OutboundSkusControllerTest < ActionDispatch::IntegrationTest
  setup do
    @outbound_sku = outbound_skus(:one)
  end

  test "should get index" do
    get outbound_skus_url
    assert_response :success
  end

  test "should get new" do
    get new_outbound_sku_url
    assert_response :success
  end

  test "should create outbound_sku" do
    assert_difference("OutboundSku.count") do
      post outbound_skus_url, params: { outbound_sku: { outbound_id: @outbound_sku.outbound_id, packaging: @outbound_sku.packaging, quantity: @outbound_sku.quantity, sku_id: @outbound_sku.sku_id } }
    end

    assert_redirected_to outbound_sku_url(OutboundSku.last)
  end

  test "should show outbound_sku" do
    get outbound_sku_url(@outbound_sku)
    assert_response :success
  end

  test "should get edit" do
    get edit_outbound_sku_url(@outbound_sku)
    assert_response :success
  end

  test "should update outbound_sku" do
    patch outbound_sku_url(@outbound_sku), params: { outbound_sku: { outbound_id: @outbound_sku.outbound_id, packaging: @outbound_sku.packaging, quantity: @outbound_sku.quantity, sku_id: @outbound_sku.sku_id } }
    assert_redirected_to outbound_sku_url(@outbound_sku)
  end

  test "should destroy outbound_sku" do
    assert_difference("OutboundSku.count", -1) do
      delete outbound_sku_url(@outbound_sku)
    end

    assert_redirected_to outbound_skus_url
  end
end
