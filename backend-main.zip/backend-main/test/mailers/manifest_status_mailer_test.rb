require "test_helper"

class ManifestStatusMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
