# Preview all emails at http://localhost:3000/rails/mailers/manifest_status_mailer
class ManifestStatusMailerPreview < ActionMailer::Preview

end
