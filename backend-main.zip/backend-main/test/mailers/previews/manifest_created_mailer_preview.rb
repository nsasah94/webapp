# Preview all emails at http://localhost:3000/rails/mailers/manifest_created_mailer
class ManifestCreatedMailerPreview < ActionMailer::Preview

end
