require 'test_helper'
class InventoryManager::CreateInventoryJobTest < Minitest::Test
  def test_example
    skip "add some examples to (or delete) #{__FILE__}"
  end
end
