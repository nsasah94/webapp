require "test_helper"

class OutboundSkuTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
