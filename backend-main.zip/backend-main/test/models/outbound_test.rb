require "test_helper"

class OutboundTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
