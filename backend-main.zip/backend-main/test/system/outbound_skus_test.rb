require "application_system_test_case"

class OutboundSkusTest < ApplicationSystemTestCase
  setup do
    @outbound_sku = outbound_skus(:one)
  end

  test "visiting the index" do
    visit outbound_skus_url
    assert_selector "h1", text: "Outbound skus"
  end

  test "should create outbound sku" do
    visit outbound_skus_url
    click_on "New outbound sku"

    fill_in "Outbound", with: @outbound_sku.outbound_id
    fill_in "Packaging", with: @outbound_sku.packaging
    fill_in "Quantity", with: @outbound_sku.quantity
    fill_in "Sku", with: @outbound_sku.sku_id
    click_on "Create Outbound sku"

    assert_text "Outbound sku was successfully created"
    click_on "Back"
  end

  test "should update Outbound sku" do
    visit outbound_sku_url(@outbound_sku)
    click_on "Edit this outbound sku", match: :first

    fill_in "Outbound", with: @outbound_sku.outbound_id
    fill_in "Packaging", with: @outbound_sku.packaging
    fill_in "Quantity", with: @outbound_sku.quantity
    fill_in "Sku", with: @outbound_sku.sku_id
    click_on "Update Outbound sku"

    assert_text "Outbound sku was successfully updated"
    click_on "Back"
  end

  test "should destroy Outbound sku" do
    visit outbound_sku_url(@outbound_sku)
    click_on "Destroy this outbound sku", match: :first

    assert_text "Outbound sku was successfully destroyed"
  end
end
